package com.oj.onlinejudge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemSamples;
import com.oj.onlinejudge.mapper.ProblemSamplesMapper;
import com.oj.onlinejudge.service.IProblemSamplesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 题目示例表 服务实现类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@Service
public class ProblemSamplesServiceImpl extends ServiceImpl<ProblemSamplesMapper, ProblemSamples> implements IProblemSamplesService {

    @Override
    public List<ProblemSamples> getSamplesByProblemId(Integer problemId) {
        return list(new QueryWrapper<ProblemSamples>().eq("problem_id", problemId));
    }
    @Transactional
    @Override
    public boolean createSample(ProblemSamples problemSamples) {
        if(problemSamples.getProblemId() != null &&  problemSamples.getSampleInput() != null && problemSamples.getSampleOutput() != null){
            problemSamples.setCreatedAt(LocalDateTime.now());
            problemSamples.setUpdatedAt(LocalDateTime.now());
            return save(problemSamples);
        }
        return false;
    }
    @Transactional
    @Override
    public boolean updateSample(ProblemSamples problemSamples) {
        problemSamples.setUpdatedAt(LocalDateTime.now());
        return updateById(problemSamples);
    }
    @Transactional
    @Override
    public boolean deleteSampleById(Integer id) {
        return remove(new QueryWrapper<ProblemSamples>().eq("id", id));
    }
    @Transactional
    @Override
    public boolean deleteSampleByProblemId(Integer problemId) {
        return remove(new QueryWrapper<ProblemSamples>().eq("problem_id", problemId));
    }

    @Override
    public Page<ProblemSamples> getSamplesByPage(Page<ProblemSamples> page, String query) {
        QueryWrapper<ProblemSamples> queryWrapper = new QueryWrapper<>();
        if (query != null && !query.trim().isEmpty()){
            queryWrapper.lambda()
                    .like(ProblemSamples::getSampleInput, query)
                    .or()
                    .like(ProblemSamples::getSampleOutput, query)
                    .or()
                    .eq(ProblemSamples::getProblemId, query);
        }
        return page(page, queryWrapper);
    }

    @Override
    public ProblemSamples getSampleById(Integer id) {
        return getById(id);
    }
}
