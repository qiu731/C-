package com.oj.onlinejudge.common;

import com.baomidou.mybatisplus.extension.handlers.AbstractJsonTypeHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

/**
 * @author : 毛晖
 * @项目名称 : OnlineJudge
 * @创建者 : 毛晖
 * @date : 2024/12/24 上午2:21
 */
public class JsonListTypeHandler extends AbstractJsonTypeHandler<List<Integer>> {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();



    @Override
    protected List<Integer> parse(String json) {
        System.out.println("JSON解析: " + json);
        try {
            return OBJECT_MAPPER.readValue(json, new TypeReference<List<Integer>>() {});
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected String toJson(List<Integer> obj) {
        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
