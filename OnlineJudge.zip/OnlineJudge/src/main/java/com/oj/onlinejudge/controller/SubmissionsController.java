package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.annotation.SaCheckRole;
import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.codec.Base64;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oj.onlinejudge.common.*;
import com.oj.onlinejudge.common.antlr.AstGenerator;
import com.oj.onlinejudge.controller.client.Judge0Client;
import com.oj.onlinejudge.domain.dto.SubmissionRequest;
import com.oj.onlinejudge.domain.po.ProblemSamples;
import com.oj.onlinejudge.domain.po.Submissions;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.domain.response.Judge0Response;
import com.oj.onlinejudge.domain.vo.ProblemVO;
import com.oj.onlinejudge.service.IProblemSamplesService;
import com.oj.onlinejudge.service.IProblemsService;
import com.oj.onlinejudge.service.ISubmissionsService;
import com.oj.onlinejudge.service.IUsersService;
import com.oj.onlinejudge.util.CodeFormatter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 提交表 前端控制器
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@Api(tags = "提交管理", description = "管理代码提交及评测")
@RestController
@RequestMapping("/submissions")
@RequiredArgsConstructor
public class SubmissionsController {

    private static final Logger log = LoggerFactory.getLogger(SubmissionsController.class);
    private static final int ACCEPTED_STATUS_ID = 3;
    private final IUsersService usersService;
    private final IProblemsService problemsService;
    private final IProblemSamplesService problemSamplesService;
    private final ISubmissionsService submitService;
    private final ObjectMapper objectMapper = new ObjectMapper();




    @ApiOperation(value = "查找提交", notes = "根据用户登录信息和题目id查找提交")
    @GetMapping("/getSubmissionByUserAndProblem")
    @SaCheckLogin
    public ApiResponse<?> getSubmissionByUserAndProblem(@RequestParam Integer problemId) {
        log.info("getSubmissionByUserAndProblem: {}", problemId);
        Submissions submissions = submitService.getSubmissionByUserAndProblem(StpUtil.getLoginIdAsInt(), problemId);
        if (
                submissions == null
        ){
            return ApiResponse.error(404, "暂无提交");
        }
        return ApiResponse.success(submissions);
    }


    @ApiOperation(value = "提交代码", notes = "提交代码并进行评测")
    @PostMapping("/submit")
    public ApiResponse<?> submitCode(@RequestBody SubmissionRequest request) {
        try {
            ResponseEntity<String> response = Judge0Client.submitCode(request);
            return new ApiResponse<>(response.getStatusCode().value(),"成功", response.getBody());
        } catch (Exception e) {

            throw new RuntimeException(e);
        }
    }

    @ApiOperation(value = "提交代码 (根据题目ID)", notes = "按题目ID提交代码并评测")
    @PostMapping("/submit/{id}")
    @SaCheckLogin
    public ApiResponse<?> submitCodeById(@RequestBody SubmissionRequest request, @PathVariable Integer id) {
        Integer userId = StpUtil.getLoginIdAsInt();
        log.info("submitCodeById: {}", id);
        if (id == null) {
            return new ApiResponse<>(400, "题目ID不能为空", null);
        }

        String formattedCode = request.getSourceCode();
        boolean isPoorStyle = false;
        try {
            isPoorStyle = AdvancedCodingStyleChecker.hasPoorCodingStyle(formattedCode);
            log.debug("Is the code style poor? {}", isPoorStyle);
        } catch (Exception e) {
            log.error("Error checking coding style", e);
            return new ApiResponse<>(500, "检查编码风格时出错: " + e.getMessage(), null);
        }

        if (!CodeStructureChecker.hasMainFunction(formattedCode)) {
            return new ApiResponse<>(400, "代码中必须包含 main 函数", null);
        }

        ProblemVO problemById = problemsService.getProblemById(id);
        if (problemById.getTimeLimit() != null) {
            request.setWallTimeLimit(Float.valueOf(problemById.getTimeLimit()) / 1000);
        }
        if (problemById.getMemoryLimit() != null) {
            request.setMemoryLimit(Float.valueOf(problemById.getMemoryLimit()));
        }

        // 获取用户ID，暂时假设为1
//        int userId = 1; // StpUtil.getLoginIdAsInt();
        usersService.incrementTotalSubmissions(userId);
        Submissions submissions = new Submissions();
        submissions.setCode(request.getSourceCode());
        submissions.setLanguage(String.valueOf(request.getLanguageId()));
        submissions.setCreatedAt(LocalDateTime.now());
        submissions.setUpdatedAt(LocalDateTime.now());
        submissions.setUserId(userId);
        submissions.setProblemId(id);

        try {
            int[] fingerprintArray = AstGenerator.extractFingerprintFromCode(request.getSourceCode());
            List<Integer> fingerprintList = Arrays.stream(fingerprintArray)
                    .boxed()
                    .collect(Collectors.toList());
            submissions.setFingerprint(fingerprintList); // 直接存 List<Integer>
        } catch (Exception e) {
            log.error("Extracting fingerprint failed", e);
            return new ApiResponse<>(400, "提取代码指纹异常", null);
        }

        List<ProblemSamples> samples = problemById.getSamples();
        boolean allPassed = true;
        int lastMemory = 0;
        int lastRuntime = 0;
        String massage = "";
        for (ProblemSamples sample : samples) {
            request.setStdin(sample.getSampleInput());
            request.setExpectedOutput(sample.getSampleOutput());
            ResponseEntity<String> response = Judge0Client.submitCode(request);
            ApiResponse<?> apiResponse = processJudge0Response(response, submissions);
            if (apiResponse.getCode() != 200) {
                log.error("Error submitting code: {}", apiResponse.getData());
                if(apiResponse.getCode() == 1002  || apiResponse.getCode() == 1003){
                    massage = (String) apiResponse.getData();
                }
                allPassed = false;
                break;
            }

            Judge0Response judge0Response = (Judge0Response) apiResponse.getData();
            lastMemory = judge0Response.getMemory();
            lastRuntime = (int) (Float.parseFloat(judge0Response.getTime()) * 1000);
        }

        if (allPassed) {
            submissions.setStatus("Accepted");
            submissions.setMessage("");
            submissions.setMemory(lastMemory);
            submissions.setRuntime(lastRuntime);
        } else {
            submissions.setMessage(massage);
            submissions.setStatus("Failed");
        }
        Submissions submissionByProblemId = submitService.getSubmissionByProblemIdAndUserId(submissions.getProblemId(), userId);
        if(submissionByProblemId != null){
            System.out.println("update");
            submissions.setId(submissionByProblemId.getId());
            submitService.updateById(submissions);
        }else {
            if (submissions.getStatus().equals("Accepted")){
                usersService.addByPoints(userId, 5);
                if (problemById.getDifficulty().equals("简单")){
                    usersService.addlevel(userId,5);
                } else if (problemById.getDifficulty().equals("中等")) {
                    usersService.addlevel(userId,10);
                }else if (problemById.getDifficulty().equals("困难")) {
                    usersService.addlevel(userId,15);
                }
            }
            submitService.save(submissions);
        }
        if(allPassed){
            usersService.incrementSuccessfulSubmissions(userId);
        }

        return allPassed ? new ApiResponse<>(200, "所有测试用例通过", submissions) :
                new ApiResponse<>(400, "部分测试用例未通过"+submissions.getMessage(), submissions);
    }


    @ApiOperation(value = "测试用例提交", notes = "测试用例提交并返回结果")
    @PostMapping("/test-case/submit/{id}")
    public ApiResponse<?> submitTestCase(@RequestBody SubmissionRequest request, @PathVariable Integer id) {
        if (request.getLanguageId() == null || request.getSourceCode() == null) {
            return new ApiResponse<>(400, "缺少必要参数", null);
        }
        ProblemSamples sample = problemSamplesService.getSampleById(id);
        request.setExpectedOutput(sample.getSampleOutput());
        if (sample.getSampleInput() != null){
            request.setStdin(sample.getSampleInput());
//            System.out.println("submitTestCase: "+request.getStdin());
//            System.out.println("submitTestCase: "+request.getExpectedOutput());
        }
        ResponseEntity<String> response = Judge0Client.submitCode(request);
        return processJudge0Response(response, new Submissions());
    }

    @ApiOperation(value = "查询题目耗时排名", notes = "获取题目下所有提交的耗时排名")
    @GetMapping("/rank/{problemId}")
    @SaCheckLogin
    public ApiResponse<?> getRankByProblemId(@PathVariable Integer problemId) {
        try {
            Map<String, Object> userRankAndPercentage = submitService.getUserRankAndPercentage( problemId,StpUtil.getLoginIdAsInt());
            return ApiResponse.success(userRankAndPercentage);
        } catch (Exception e) {
            log.error("获取耗时排名失败: {}", e.getMessage(), e);
            return ApiResponse.error(500, "获取耗时排名失败");
        }
    }


    @ApiOperation(value = "分页查询提交记录", notes = "支持条件查询和分页")
    @GetMapping("/page")
    public ApiResponse<Page<Submissions>> getSubmissionsByPage(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query) {

        Page<Submissions> page = new Page<>(current, size);
        Page<Submissions> resultPage = submitService.getSubmissionsByPage(page, query);
        return ApiResponse.success(resultPage);
    }
    @ApiOperation(value = "分页查询提交记录", notes = "支持条件查询和分页")
    @GetMapping("/page/user")
    @SaCheckLogin
    public ApiResponse<Page<Submissions>> getSubmissionsByPageByUserID(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query) {

        Page<Submissions> page = new Page<>(current, size);
        Page<Submissions> resultPage = submitService.getSubmissionsByPage(page, query, StpUtil.getLoginIdAsInt());
        return ApiResponse.success(resultPage);
    }

    @ApiOperation(value = "根据题目ID分页查询提交记录", notes = "查询特定题目的提交记录")
    @GetMapping("/page/problem/{problemId}")
    public ApiResponse<Page<Submissions>> getSubmissionsByProblemId(
            @PathVariable Integer problemId,
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size) {

        Page<Submissions> page = new Page<>(current, size);
        Page<Submissions> resultPage = submitService.getSubmissionsByProblemId(page, problemId);
        return ApiResponse.success(resultPage);
    }

    @ApiOperation(value = "查询提交记录详情", notes = "根据ID查询提交记录详细信息")
    @GetMapping("/detail/{id}")
    public ApiResponse<Submissions> getSubmissionById(@PathVariable Integer id) {
        Submissions submission = submitService.getById(id);
        if (submission == null) {
            return ApiResponse.failure(404, "提交记录不存在");
        }
        return ApiResponse.success(submission);
    }


    @ApiOperation("根据提交 ID 计算最高相似度并更新重复率")
    @GetMapping("/similarity/update/{submissionId}")
    public ApiResponse<?> updateSimilarityAndGetResult(@PathVariable Integer submissionId) {
        try {
            // 调用 Service 方法
            Map<String, Object> result = submitService.updateSimilarityAndGetResult(submissionId);

            // 返回成功响应
            return new ApiResponse<>(200, "相似度计算完成", result);
        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse<>(400, e.getMessage(), null);
        }
    }

    @ApiOperation("对指定题目的所有提交进行查重并更新重复率")
    @PostMapping("/similarity/compute/{problemId}")
    public ApiResponse<?> computeSimilarityForProblem(@PathVariable Integer problemId) {
        try {
            // 调用 Service 层方法
            submitService.computeSimilarityForProblem(problemId);
            return new ApiResponse<>(200, "查重完成并已更新重复率", null);
        } catch (Exception e) {
            log.error("Error during similarity computation: {}", e.getMessage(), e);
            return new ApiResponse<>(400, "查重失败: " + e.getMessage(), null);
        }
    }


    /**
     * 删除提交记录
     */
    @ApiOperation(value = "删除提交记录", notes = "根据ID删除提交记录")
    @DeleteMapping("/deleteById/{id}")
    @Transactional
    public ApiResponse<?> deleteSubmissionById(@PathVariable Integer id) {
        boolean success = submitService.removeById(id);
        if (success) {
            return ApiResponse.success("删除成功");
        } else {
            return ApiResponse.error();
        }
    }

    /**
     * 批量删除提交记录
     */
    @ApiOperation(value = "批量删除提交记录", notes = "根据ID列表批量删除提交记录")
    @PostMapping("/deleteBatch")
    @Transactional
    public ApiResponse<?> deleteSubmissionsBatch(@RequestBody List<Integer> ids) {
        boolean success = submitService.removeByIds(ids);
        if (success) {
            return ApiResponse.success("批量删除成功");
        } else {
            return ApiResponse.error();
        }
    }

    @ApiOperation(value = "教师手动打分", notes = "教师根据ID手动评分")
    @PostMapping("/score/{id}")
    @Transactional
    public ApiResponse<?> scoreSubmission(@PathVariable Integer id, @RequestParam Integer score) {
        Submissions submission = submitService.getById(id);
        if (submission == null) {
            return ApiResponse.error(404, "提交记录不存在");
        }
        if (score < 0 || score > 100) {
            return ApiResponse.error(400, "分数范围应在 0 到 100 之间");
        }
        if (!submission.getStatus().equals("Accepted")){
            return ApiResponse.error(400, "提交记录未通过，无法打分");
        }
        submission.setScore(score);
        try {
            boolean updated = submitService.updateById(submission);
            usersService.addByTotalScore(submission.getUserId(), score);
            usersService.totalScore(submission.getUserId());
            return updated ? ApiResponse.success("评分成功") : ApiResponse.error(400, "评分失败");

        }catch (Exception e){
            log.error("Error during submission scoring: {}", e.getMessage(), e);
            return ApiResponse.error(500, "评分失败,详情查看日志");
        }

    }


    private ApiResponse<?> processJudge0Response(ResponseEntity<String> response, Submissions submissions) {
        try {
            Judge0Response judge0Response = objectMapper.readValue(response.getBody(), Judge0Response.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                if (judge0Response.getStatus().getId() == ACCEPTED_STATUS_ID) {
                    submissions.setMemory(judge0Response.getMemory());
                    float i = Float.parseFloat(judge0Response.getTime()) * 1000;
                    submissions.setRuntime((int) i);
                    submissions.setStatus("Accepted");
                    judge0Response.setStdout(Base64.decodeStr(judge0Response.getStdout()));
                    return new ApiResponse<>(200, "成功", judge0Response);
                } else {
                    submissions.setStatus(judge0Response.getStatus().getDescription());
                    if (judge0Response.getCompileOutput() != null) {
                        String decodedCompileOutput = Base64.decodeStr(judge0Response.getCompileOutput());
                        judge0Response.setCompileOutput(decodedCompileOutput);
                        judge0Response.setStdout(Base64.decodeStr(judge0Response.getStdout()));
                        return new ApiResponse<>(1002, "代码运行出错啦", decodedCompileOutput);
                    } else if (judge0Response.getMessage() != null) {
                        return new ApiResponse<>(1003, "代码运行出错啦", Base64.decodeStr(judge0Response.getMessage()));
                    }
                }
            }
            if (judge0Response.getStatus().getId() == 4){
                judge0Response.setStdout(Base64.decodeStr(judge0Response.getStdout()));
                return new ApiResponse<>(1006, "与预期结果不符", judge0Response);
            }
            judge0Response.setStdout(Base64.decodeStr(judge0Response.getStdout()));
            return new ApiResponse<>(1001, "代码运行出错啦", judge0Response);
        } catch (JsonProcessingException e) {
            log.error("Failed to parse response", e);
            return new ApiResponse<>(500, "解析响应失败: " + e.getMessage(), null);
        }
    }

    @ApiOperation(value = "测试代码格式化", notes = "测试代码格式化功能")
    @SaCheckLogin
    @SaCheckRole("teacher")
    @PostMapping("/test")
    public String test(@RequestBody String code) {
        log.info("Received code: {}", code);
        String formattedCode = CodeFormatter.formatCode(code);
        log.info("Formatted code: {}", formattedCode);
        return formattedCode;
    }
}
