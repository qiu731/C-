package com.oj.onlinejudge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemSamples;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 题目示例表 服务类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
public interface IProblemSamplesService extends IService<ProblemSamples> {
    List<ProblemSamples> getSamplesByProblemId(Integer problemId);
    boolean createSample(ProblemSamples problemSamples);
    boolean updateSample(ProblemSamples problemSamples);
    boolean deleteSampleById(Integer id);
    boolean deleteSampleByProblemId(Integer problemId);
    Page<ProblemSamples> getSamplesByPage(Page<ProblemSamples> page, String query);

    ProblemSamples getSampleById(Integer id);
}
