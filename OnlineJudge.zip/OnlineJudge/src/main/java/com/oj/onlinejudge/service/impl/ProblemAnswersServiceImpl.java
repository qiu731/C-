package com.oj.onlinejudge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.oj.onlinejudge.domain.po.ProblemAnswers;
import com.oj.onlinejudge.mapper.ProblemAnswersMapper;
import com.oj.onlinejudge.service.IProblemAnswersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 题目答案表 服务实现类
 * </p>
 *
 * @author flower
 * @since 2024-12-25
 */
@Service
public class ProblemAnswersServiceImpl extends ServiceImpl<ProblemAnswersMapper, ProblemAnswers> implements IProblemAnswersService {

    @Override
    public ProblemAnswers getByProblemID(Integer problemId) {
        QueryWrapper<ProblemAnswers> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("problem_id", problemId);
        return getOne(queryWrapper);
    }
}
