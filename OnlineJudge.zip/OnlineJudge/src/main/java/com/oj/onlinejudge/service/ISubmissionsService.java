package com.oj.onlinejudge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.Submissions;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 提交表 服务类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
public interface ISubmissionsService extends IService<Submissions> {

    long countSubmissions();

    long countAcceptedSubmissions();

    List<Submissions> getRecentSubmissions(int limit);

    Submissions getSubmissionByProblemId(Integer problemId);

    Page<Submissions> getSubmissionByProblemId(Integer problemId, int pageSize, int pagNum);

    Submissions getSubmissionByProblemIdAndUserId(Integer problemId, Integer userId);

    Page<Submissions> getSubmissionsByPage(Page<Submissions> page, String query);

    Page<Submissions> getSubmissionsByProblemId(Page<Submissions> page, Integer problemId);


    Map<String, Object> updateSimilarityAndGetResult(int submissionId);

    @Transactional
    void computeSimilarityForProblem(int problemId);

    Submissions getSubmissionByUserAndProblem(int loginIdAsInt, Integer problemId);


    Map<String, Object> getUserRankAndPercentage(Integer problemId, Integer userId);

    Page<Submissions> getSubmissionsByPage(Page<Submissions> page, String query, int loginIdAsInt);
}
