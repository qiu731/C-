package com.oj.onlinejudge.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemSamples;
import com.oj.onlinejudge.domain.po.Problems;
import com.baomidou.mybatisplus.extension.service.IService;
import com.oj.onlinejudge.domain.vo.ProblemVO;

import java.util.List;

/**
 * <p>
 * 题目表 服务类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
public interface IProblemsService extends IService<Problems> {

    Integer createProblem(Problems problems);


    boolean updateProblem(Problems problems);


    boolean deleteProblemById(Integer id);

    Page<Problems> getProblemsByPage(Page<Problems> page, String keyword, String difficulty);

    ProblemVO getProblemById(Integer id);

    List<Problems> getAllProblems();

    long countProblems();

    List<Problems> getRecentProblems(int limit);


    IPage<Problems> getProblemsByPageByUser(Page<Problems> page, String query, String difficulty);
}
