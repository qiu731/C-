package com.oj.onlinejudge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemComments;
import com.oj.onlinejudge.mapper.ProblemCommentsMapper;
import com.oj.onlinejudge.service.IProblemCommentsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 题目评论表 服务实现类
 * </p>
 *
 * @author flower
 * @since 2024-12-23
 */
@Service
public class ProblemCommentsServiceImpl extends ServiceImpl<ProblemCommentsMapper, ProblemComments> implements IProblemCommentsService {

    @Override
    public boolean addComment(ProblemComments comment) {
        // 违禁词检查逻辑
        if (containsForbiddenWords(comment.getComment())) {
            throw new RuntimeException("评论包含违禁词");
        }
        comment.setCreatedAt(LocalDateTime.now());
        comment.setUpdatedAt(LocalDateTime.now());
        return save(comment);
    }

    @Override
    public boolean deleteCommentById(Integer id) {
        return removeById(id);
    }

    @Override
    public List<ProblemComments> getCommentsByProblemId(Integer problemId) {
        return list(new QueryWrapper<ProblemComments>().eq("problem_id", problemId));
    }

    @Override
    public Page<ProblemComments> adminGetCommentsPage(Page<ProblemComments> page, String query) {
        if (query != null){
            return page(page, new QueryWrapper<ProblemComments>()
                    .like("comment", query)
                    .or()
                    .eq("user_id", query)
                    .or()
                    .eq("problem_id", query)
                    .or()
                    .eq("id", query)
                    .or()
                    .like("username", query)
                    .or()
                    .like("problem_title", query)
            );
        }
        return page(page, new QueryWrapper<>());
    }

    private boolean containsForbiddenWords(String comment) {
        // 实现违禁词检查逻辑
        // 这里只是一个示例，你应该根据实际需求实现
        String[] forbiddenWords = {"傻", "垃圾"};
        for (String word : forbiddenWords) {
            if (comment.contains(word)) {
                return true;
            }
        }
        return false;
    }
}
