package com.oj.onlinejudge.controller;

import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.service.IProblemsService;
import com.oj.onlinejudge.service.ISubmissionsService;
import com.oj.onlinejudge.service.IUsersService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : 毛晖
 * @项目名称 : OnlineJudge
 * @创建者 : 毛晖
 * @date : 2024/12/23 上午10:24
 */
@Api(tags = "仪表盘管理", description = "提供仪表盘统计数据与最近记录")
@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final IProblemsService problemsService;
    private final ISubmissionsService submissionsService;
    private final IUsersService usersService;

    /**
     * 获取仪表盘统计数据
     * @return 统计数据
     */
    @ApiOperation(value = "获取统计数据", notes = "返回题目、提交、通过和用户总数统计数据")
    @GetMapping("/stats")
    public ApiResponse<Map<String, Object>> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("problemCount", problemsService.countProblems());
        stats.put("submissionCount", submissionsService.countSubmissions());
        stats.put("acceptedCount", submissionsService.countAcceptedSubmissions());
        stats.put("userCount", usersService.countUsers());
        return ApiResponse.success(stats);
    }

    /**
     * 获取最近提交记录
     * @return 最近提交记录
     */
    @ApiOperation(value = "获取最近提交记录", notes = "返回最近 10 条提交记录")
    @GetMapping("/recent-submissions")
    public ApiResponse<List<?>> getRecentSubmissions() {
        return ApiResponse.success(submissionsService.getRecentSubmissions(10));
    }

    /**
     * 获取最近活跃用户
     * @return 最近活跃用户
     */
    @ApiOperation(value = "获取最近活跃用户", notes = "返回最近 10 个活跃用户")
    @GetMapping("/recent-users")
    public ApiResponse<List<?>> getRecentUsers() {
        return ApiResponse.success(usersService.getRecentUsers(10));
    }
}

