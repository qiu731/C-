package com.oj.onlinejudge.controller.client;

import cn.hutool.core.codec.Base64;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.oj.onlinejudge.domain.dto.SubmissionRequest;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/28 上午11:35
 */
public class Judge0Client {

    private static final String BASE_URL = "http://192.168.21.129:2358/submissions";
    private static final RestTemplate restTemplate = new RestTemplate();

    /**
     * 提交代码到 Judge0 并获取响应
     *
     * @param request 包含提交代码所需的所有参数
     * @return Judge0 响应
     */
    public static ResponseEntity<String> submitCode(SubmissionRequest request) {
        // 构建请求体
        Map<String, Object> requestBody = new HashMap<>();
//        System.out.println(request);
        requestBody.put("source_code", Base64.encode(request.getSourceCode()));
        requestBody.put("language_id", request.getLanguageId());

        if (request.getCompilerOptions() != null) {
            requestBody.put("compiler_options", request.getCompilerOptions());
        }
        if (request.getCommandLineArguments() != null) {
            requestBody.put("command_line_arguments", request.getCommandLineArguments());
        }
        if (request.getStdin() != null) {
            requestBody.put("stdin", Base64.encode(request.getStdin()));
        }
        if (request.getExpectedOutput() != null) {
            requestBody.put("expected_output", Base64.encode(request.getExpectedOutput()));
        }
        if (request.getCpuTimeLimit() != null) {
            requestBody.put("cpu_time_limit", request.getCpuTimeLimit());
        }
        if (request.getCpuExtraTime() != null) {
            requestBody.put("cpu_extra_time", request.getCpuExtraTime());
        }
        if (request.getWallTimeLimit() != null) {
            requestBody.put("wall_time_limit", request.getWallTimeLimit());
        }
        if (request.getMemoryLimit() != null) {
            requestBody.put("memory_limit", request.getMemoryLimit());
        }
        if (request.getStackLimit() != null) {
            requestBody.put("stack_limit", request.getStackLimit());
        }
        if (request.getMaxProcessesAndOrThreads() != null) {
            requestBody.put("max_processes_and_or_threads", request.getMaxProcessesAndOrThreads());
        }
        if (request.getEnablePerProcessAndThreadTimeLimit() != null) {
            requestBody.put("enable_per_process_and_thread_time_limit", request.getEnablePerProcessAndThreadTimeLimit());
        }
        if (request.getEnablePerProcessAndThreadMemoryLimit() != null) {
            requestBody.put("enable_per_process_and_thread_memory_limit", request.getEnablePerProcessAndThreadMemoryLimit());
        }
        if (request.getMaxFileSize() != null) {
            requestBody.put("max_file_size", request.getMaxFileSize());
        }
        if (request.getRedirectStderrToStdout() != null) {
            requestBody.put("redirect_stderr_to_stdout", request.getRedirectStderrToStdout());
        }
        if (request.getEnableNetwork() != null) {
            requestBody.put("enable_network", request.getEnableNetwork());
        }
        if (request.getNumberOfRuns() != null) {
            requestBody.put("number_of_runs", request.getNumberOfRuns());
        }
        if (request.getAdditionalFiles() != null) {
            requestBody.put("additional_files", request.getAdditionalFiles());
        }
        if (request.getCallbackUrl() != null) {
            requestBody.put("callback_url", request.getCallbackUrl());
        }
        System.out.println(requestBody);

        // 设置请求头
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        // 发送 POST 请求
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(BASE_URL+"?base64_encoded=true&wait=true", requestEntity, String.class);

        // 解析响应以获取 token
        JSONObject jsonObject = JSONUtil.parseObj(responseEntity.getBody());
        String token = jsonObject.getStr("token");
        System.out.println("token: " + token);

        // 使用 token 获取提交结果
        return getSubmissionResult(token);
    }

    /**
     * 使用 token 获取提交结果
     *
     * @param token 提交的 token
     * @return 提交结果
     */
    public static ResponseEntity<String> getSubmissionResult(String token) {
        String url = BASE_URL + "/" + token + "?base64_encoded=true";

        // 设置请求头
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        // 发送 GET 请求
        return restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
    }
}