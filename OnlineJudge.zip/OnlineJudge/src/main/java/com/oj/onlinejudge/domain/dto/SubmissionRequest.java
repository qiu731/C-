package com.oj.onlinejudge.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 提交请求 DTO
 *
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/28 下午12:06
 */
@Data
public class SubmissionRequest implements Serializable {

    @ApiModelProperty(value = "代码", required = true, example = "public class Main { public static void main(String[] args) { System.out.println(\"Hello, World!\"); } }")
    private String sourceCode;

    @ApiModelProperty(value = "语言 ID", required = true, example = "1", notes = "请参考支持的语言列表")
    private Integer languageId;

    @ApiModelProperty(value = "编译器选项", example = "-O2")
    private String compilerOptions;

    @ApiModelProperty(value = "命令行参数", example = "arg1 arg2")
    private String commandLineArguments;

    @ApiModelProperty(value = "标准输入", example = "input data")
    private String stdin;

    @ApiModelProperty(value = "预期输出", example = "expected output")
    private String expectedOutput;

    @ApiModelProperty(value = "CPU 时间限制 (秒)", example = "5.0")
    private Float cpuTimeLimit;

    @ApiModelProperty(value = "CPU 额外时间 (秒)", example = "2.0")
    private Float cpuExtraTime;

    @ApiModelProperty(value = "墙钟时间限制 (秒)", example = "10.0")
    private Float wallTimeLimit;

    @ApiModelProperty(value = "内存限制 (KB)", example = "102400")
    private Float memoryLimit;

    @ApiModelProperty(value = "栈限制 (KB)", example = "8192")
    private Integer stackLimit;

    @ApiModelProperty(value = "最大进程和线程数", example = "10")
    private Integer maxProcessesAndOrThreads;

    @ApiModelProperty(value = "是否启用每个进程的时间限制", example = "true")
    private Boolean enablePerProcessAndThreadTimeLimit;

    @ApiModelProperty(value = "是否启用每个进程的内存限制", example = "true")
    private Boolean enablePerProcessAndThreadMemoryLimit;

    @ApiModelProperty(value = "文件大小限制 (KB)", example = "1024")
    private Integer maxFileSize;

    @ApiModelProperty(value = "是否将标准错误重定向到标准输出", example = "true")
    private Boolean redirectStderrToStdout;

    @ApiModelProperty(value = "是否启用网络访问", example = "false")
    private Boolean enableNetwork;

    @ApiModelProperty(value = "运行次数", example = "3")
    private Integer numberOfRuns;

    @ApiModelProperty(value = "附加文件 (Base64 编码的 ZIP 文件)", example = "UEsDBBQABgAIAAAAIQA...") // 这里只是示例，实际值应为有效的 Base64 编码字符串
    private String additionalFiles;

    @ApiModelProperty(value = "回调 URL", example = "http://example.com/callback")
    private String callbackUrl;
}