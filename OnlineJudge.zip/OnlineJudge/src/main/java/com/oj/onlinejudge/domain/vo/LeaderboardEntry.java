package com.oj.onlinejudge.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author : 毛晖
 * @项目名称 : OnlineJudge
 * @创建者 : 毛晖
 * @date : 2024/12/26 上午7:13
 */
@Data
@AllArgsConstructor
public class LeaderboardEntry {
    private String username;
    private Object value; // 可以是通过数、正确率或总得分
}

