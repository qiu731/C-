package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import com.alibaba.dashscope.aigc.generation.Generation;
import com.alibaba.dashscope.aigc.generation.GenerationParam;
import com.alibaba.dashscope.aigc.generation.GenerationResult;
import com.alibaba.dashscope.common.Message;
import com.alibaba.dashscope.common.Role;
import com.alibaba.dashscope.exception.InputRequiredException;
import com.alibaba.dashscope.exception.NoApiKeyException;
import com.oj.onlinejudge.domain.po.Submissions;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.service.ISubmissionsService;
import com.oj.onlinejudge.service.IUsersService;
import com.oj.onlinejudge.service.impl.UsersServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import javax.servlet.http.HttpServletResponse;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/11 下午11:37
 */
@Api(tags = "AI交互控制器", description = "处理AI文本生成、代码优化和评分的控制器") // 类描述
@RestController

@RequestMapping("/ai")
public class AiController {
    private final Generation generation;
    private final ISubmissionsService submissionsService;
    private final IUsersService usersServiceImpl;
    @Value("${ai.api.key}")
    private String appKey;

    @Autowired
    public AiController(Generation generation, ISubmissionsService submissionsService, UsersServiceImpl usersServiceImpl) {
        this.generation = generation;
        this.submissionsService = submissionsService;
        this.usersServiceImpl = usersServiceImpl;
    }

    @ApiOperation(value = "AI交互接口", notes = "根据用户问题进行AI对话，并返回答案")
    @PostMapping(value = "/send")
    public Mono<Map<String, String>> aiTalk(@RequestBody String question, HttpServletResponse response) {
        Message message = Message.builder().role(Role.USER.getValue()).content(question).build();

        GenerationParam param = GenerationParam.builder()
                .model(Generation.Models.QWEN_PLUS)
                .messages(Collections.singletonList(message))
                .resultFormat(GenerationParam.ResultFormat.MESSAGE)
                .topP(0.75)
                .maxTokens(2048)
                .temperature(0.7F)
                .apiKey(appKey)
                .build();

        Instant start = Instant.now();

        return Mono.fromCallable(() -> {
            try {
                GenerationResult result = generation.call(param);
                Instant end = Instant.now();
                Duration duration = Duration.between(start, end);
                System.out.println("API 调用耗时: " + duration.toMillis() + " 毫秒");

                String content = result.getOutput().getChoices().get(0).getMessage().getContent();
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("answer", content);
                return responseMap;
            } catch (NoApiKeyException | InputRequiredException e) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("error", "请求错误: " + e.getMessage());
                return errorResponse;
            } catch (Exception e) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("error", "内部错误: " + e.getMessage());
                return errorResponse;
            }
        }).subscribeOn(Schedulers.boundedElastic());
    }

    @ApiOperation(value = "代码优化接口", notes = "对C++代码进行优化并返回优化后的代码")
    @PostMapping(value = "/optimize-code")
    public Mono<Map<String, String>> optimizeCode(@RequestBody String code, HttpServletResponse response) {
        String prompt = "请优化以下C++代码:\n" + code + "\n优化后的代码为：\n";
        Message message = Message.builder().role(Role.USER.getValue()).content(prompt).build();

        GenerationParam param = GenerationParam.builder()
                .model(Generation.Models.QWEN_PLUS)
                .messages(Collections.singletonList(message))
                .resultFormat(GenerationParam.ResultFormat.MESSAGE)
                .topP(0.75)
                .maxTokens(2048)
                .temperature(0.7F)
                .apiKey(appKey)
                .build();

        return Mono.fromCallable(() -> {
            try {
                GenerationResult result = generation.call(param);
                String content = result.getOutput().getChoices().get(0).getMessage().getContent();
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("optimized_code", content.trim());
                return responseMap;
            } catch (NoApiKeyException | InputRequiredException e) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("error", "请求错误: " + e.getMessage());
                return errorResponse;
            } catch (Exception e) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("error", "内部错误: " + e.getMessage());
                return errorResponse;
            }
        }).subscribeOn(Schedulers.boundedElastic());
    }

    @ApiOperation(value = "代码评分接口", notes = "对C++代码的风格和逻辑进行评分，并返回评分结果")
    @PostMapping(value = "/score-code")
    public Mono<ApiResponse<?>> scoreCode(@RequestBody String code) {
        return scoreByCode(code);
    }



    @ApiOperation(value = "测试接口", notes = "用于测试控制器是否可用")
    @GetMapping("/test")
    public String test() {
        return "hello";
    }

    @ApiOperation(value = "根据提交记录打分", notes = "传入提交记录ID，根据状态调用AI打分并更新数据库")
    @PostMapping("/score-submission/{id}")
    @SaCheckLogin
    public Mono<ApiResponse<?>> scoreSubmission(@PathVariable Integer id) {
        // 1. 查询提交记录
        Submissions submission = submissionsService.getById(id);
        if (submission == null) {
            return Mono.just(ApiResponse.failure(404, "提交记录不存在"));
        }

        // 2. 检查提交状态
        if (!"Accepted".equals(submission.getStatus())) {
            return Mono.just(ApiResponse.failure(400, "提交状态不是 Accepted，无法进行评分"));
        }

        // 3. 调用 AI 打分接口
        String code = submission.getCode();
        return scoreByCode(code)
                .map(response -> {
                    if (response.getCode() != 200) {
                        return ApiResponse.failure(500, "AI 打分失败");
                    }

                    // 4. 更新提交记录的评分
                    Map<String, String> data = (Map<String, String>) response.getData();
                    String scoreStr = data.get("score");
                    try {
                        int score = Integer.parseInt(scoreStr);
                        submission.setScore(score);
                        submission.setUpdatedAt(LocalDateTime.now());
                        boolean updateResult = submissionsService.updateById(submission);
                        usersServiceImpl.totalScore(submission.getUserId());
                        if (updateResult) {
                            return ApiResponse.success("评分成功");
                        } else {
                            return ApiResponse.failure(500, "评分成功，但更新数据库失败");
                        }
                    } catch (NumberFormatException e) {
                        return ApiResponse.failure(500, "AI 返回评分格式错误: " + scoreStr);
                    }
                })
                .subscribeOn(Schedulers.boundedElastic());
    }
    @ApiOperation(value = "根据提交记录ID优化代码", notes = "通过提交记录ID获取代码内容并优化")
    @GetMapping("/optimize-submission/{id}")
    @SaCheckLogin
    public Mono<ApiResponse<?>> optimizeSubmission(@PathVariable Integer id) {
        // 1. 查询提交记录
        Submissions submission = submissionsService.getById(id);
        if (submission == null) {
            return Mono.just(ApiResponse.failure(404, "提交记录不存在"));
        }

        // 2. 检查提交状态
        if (!"Accepted".equals(submission.getStatus())) {
            return Mono.just(ApiResponse.failure(400, "提交状态不是 Accepted，无法进行优化"));
        }

        // 3. 获取代码内容
        String code = submission.getCode();
        String prompt = "请优化以下C++代码:\n" + code + "\n优化后的代码为：\n";

        // 4. 调用 AI 优化接口
        Message message = Message.builder().role(Role.USER.getValue()).content(prompt).build();
        GenerationParam param = GenerationParam.builder()
                .model(Generation.Models.QWEN_PLUS)
                .messages(Collections.singletonList(message))
                .resultFormat(GenerationParam.ResultFormat.MESSAGE)
                .topP(0.75)
                .maxTokens(2048)
                .temperature(0.7F)
                .apiKey(appKey)
                .build();

        return Mono.fromCallable(() -> {
            try {
                // 调用 AI 服务
                GenerationResult result = generation.call(param);
                String optimizedCode = result.getOutput().getChoices().get(0).getMessage().getContent().trim();

                // 构造响应数据
                Map<String, String> responseData = new HashMap<>();
                responseData.put("original_code", code);
                responseData.put("optimized_code", optimizedCode);

                return ApiResponse.success(responseData);
            } catch (NoApiKeyException | InputRequiredException e) {
                return ApiResponse.failure(400, "AI 请求错误: " + e.getMessage());
            } catch (Exception e) {
                return ApiResponse.failure(500, "内部错误: " + e.getMessage());
            }
        }).subscribeOn(Schedulers.boundedElastic());
    }


    private Mono<ApiResponse<?>> scoreByCode(String code) {
        String prompt = "请对以下C++代码进行风格逻辑综合评分,满分100只给出评估后的分数:\n" + code + "\n只需要分数，除了分数不要输出任何东西：\n";
        Message message = Message.builder().role(Role.USER.getValue()).content(prompt).build();

        GenerationParam param = GenerationParam.builder()
                .model(Generation.Models.QWEN_PLUS)
                .messages(Collections.singletonList(message))
                .resultFormat(GenerationParam.ResultFormat.MESSAGE)
                .topP(0.75)
                .maxTokens(2048)
                .temperature(0.7F)
                .apiKey(appKey)
                .build();

        Mono<Map<String, String>> mapMono = Mono.fromCallable(() -> {
            try {
                GenerationResult result = generation.call(param);
                String content = result.getOutput().getChoices().get(0).getMessage().getContent();
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("score", content.trim());
                return responseMap;
            } catch (Exception e) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("error", "内部错误: " + e.getMessage());
                return errorResponse;
            }
        }).subscribeOn(Schedulers.boundedElastic());

        return mapMono.map(responseMap -> {
            if (responseMap.containsKey("error")) {
                return new ApiResponse<>(500, "失败", responseMap);
            } else {
                return new ApiResponse<>(200, "成功", responseMap);
            }
        });

    }
}
