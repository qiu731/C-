package com.oj.onlinejudge.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.common.antlr.FingerprintExtractor;
import com.oj.onlinejudge.domain.po.Submissions;
import com.oj.onlinejudge.mapper.SubmissionsMapper;
import com.oj.onlinejudge.service.ISubmissionsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 提交表 服务实现类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@Service
public class SubmissionsServiceImpl extends ServiceImpl<SubmissionsMapper, Submissions> implements ISubmissionsService {
    @Override
    public long countSubmissions() {
        return count();
    }

    @Override
    public long countAcceptedSubmissions() {
        return count(new QueryWrapper<Submissions>().eq("status", "Accepted"));
    }

    @Override
    public List<Submissions> getRecentSubmissions(int limit) {
        return list(new QueryWrapper<Submissions>().orderByDesc("created_at").last("LIMIT " + limit));
    }

    @Override
    public Submissions getSubmissionByProblemId(Integer problemId){
        return getOne(new QueryWrapper<Submissions>().eq("problem_id", problemId).orderByDesc("created_at").last("LIMIT 1"));
    }
    @Override
    public Page<Submissions> getSubmissionByProblemId(Integer problemId, int pageSize, int pagNum){
        return page(new Page<>(pageSize, pagNum), new QueryWrapper<Submissions>().eq("problem_id", problemId).orderByDesc("created_at"));
    }
    @Override
    public Submissions getSubmissionByProblemIdAndUserId(Integer problemId, Integer userId){
        return getOne(new QueryWrapper<Submissions>().eq("problem_id", problemId).eq("user_id", userId).orderByDesc("created_at").last("LIMIT 1"));
    }

    @Override
    public Page<Submissions> getSubmissionsByPage(Page<Submissions> page, String query) {
        QueryWrapper<Submissions> wrapper = new QueryWrapper<>();
        if (StringUtils.hasText(query)) {
            wrapper.like("code", query)
                    .or().like("status", query)
                    .or().like("language", query);
        }
        wrapper.orderByDesc("created_at");
        return page(page, wrapper);
    }

    @Override
    public Page<Submissions> getSubmissionsByPage(Page<Submissions> page, String query, int userId) {
        QueryWrapper<Submissions> wrapper = new QueryWrapper<>();

        wrapper.eq("user_id", userId)
                .orderByDesc("created_at");
        return page(page, wrapper);
    }


    @Override
    public Page<Submissions> getSubmissionsByProblemId(Page<Submissions> page, Integer problemId) {
        QueryWrapper<Submissions> wrapper = new QueryWrapper<>();
        wrapper.eq("problem_id", problemId).orderByDesc("created_at");
        return page(page, wrapper);
    }




    @Override
    public Map<String, Object> updateSimilarityAndGetResult(int submissionId) {
        // 获取当前提交记录
        Submissions currentSubmission = getById(submissionId);
        System.out.println("currentSubmission: " + currentSubmission);
        if (currentSubmission == null) {
            throw new RuntimeException("提交记录不存在！");
        }

        // 获取题目 ID 和当前指纹
        int problemId = currentSubmission.getProblemId();
        List<Integer> currentFingerprint = currentSubmission.getFingerprint();

        // 查询指定题目的所有提交记录
        List<Submissions> submissions = list(
                new QueryWrapper<Submissions>().eq("problem_id", problemId)
        );

        // 如果提交数小于 2 或指纹为空，则无法比较相似度
        System.out.println(submissions.size());
        System.out.println(currentFingerprint);
//        System.out.println(currentFingerprint.isEmpty());
        if (submissions.size() < 2 || currentFingerprint == null || currentFingerprint.isEmpty()) {
            throw new RuntimeException("数据不足或指纹为空，无法进行相似度计算！");
        }

        // 计算最高相似度
        double maxSimilarity = 0.0; // 记录最大相似度
        Submissions mostSimilarSubmission = null; // 存储最相似的提交记录

        for (Submissions submission : submissions) {
            if (submission.getId().equals(currentSubmission.getId())) {
                continue; // 跳过自身记录
            }

            // 获取其他提交记录的指纹
            List<Integer> fingerprint = submission.getFingerprint();
            if (fingerprint == null || fingerprint.isEmpty()) {
                continue; // 跳过指纹为空的记录
            }

            // 计算相似度
            double similarity = FingerprintExtractor.computeSimilarity(
                    currentFingerprint.stream().mapToInt(Integer::intValue).toArray(),
                    fingerprint.stream().mapToInt(Integer::intValue).toArray()
            );

            // 更新最高相似度和最相似记录
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity;
                mostSimilarSubmission = submission;
            }
        }

        // 更新当前提交记录的重复率
        BigDecimal duplicationRate = BigDecimal.valueOf(maxSimilarity * 100); // 百分比形式
        currentSubmission.setDuplicationRate(duplicationRate);
        updateById(currentSubmission); // 更新数据库记录

        // 返回结果
        Map<String, Object> result = new HashMap<>();
        result.put("maxSimilarity", duplicationRate);
        result.put("mostSimilarSubmissionId", mostSimilarSubmission != null ? mostSimilarSubmission.getId() : null);
        result.put("currentSubmission", currentSubmission); // 更新后的记录

        return result;
    }


    @Transactional
    @Override
    public void computeSimilarityForProblem(int problemId) {
        // 按题目 ID 查询所有提交记录，按更新时间降序排序
        List<Submissions> submissions = list(
                new QueryWrapper<Submissions>()
                        .eq("problem_id", problemId)
                        .orderByDesc("updated_at")
        );

        if (submissions.isEmpty()) {
            throw new RuntimeException("当前题目没有任何提交记录！");
        }

        // 遍历记录，按顺序计算重复率
        for (int i = 0; i < submissions.size(); i++) {
            Submissions current = submissions.get(i);

            // 第一条记录的重复率直接设为 0
            if (i == submissions.size() - 1) {
                current.setDuplicationRate(BigDecimal.ZERO);
                updateById(current);
                continue;
            }

            double maxSimilarity = 0.0; // 初始化最大相似度
            Submissions mostSimilarSubmission = null; // 存储最相似的记录

            // 当前记录与之前的所有记录进行比对
            for (int j = i + 1; j < submissions.size(); j++) {
                Submissions previous = submissions.get(j);

                // 获取指纹
                List<Integer> currentFingerprint = current.getFingerprint();
                List<Integer> previousFingerprint = previous.getFingerprint();

                // 检查指纹是否为空
                if (currentFingerprint == null || previousFingerprint == null
                        || currentFingerprint.isEmpty() || previousFingerprint.isEmpty()) {
                    continue;
                }

                // 计算指纹相似度
                double similarity = FingerprintExtractor.computeSimilarity(
                        currentFingerprint.stream().mapToInt(Integer::intValue).toArray(),
                        previousFingerprint.stream().mapToInt(Integer::intValue).toArray()
                );

                // 更新最大相似度
                if (similarity > maxSimilarity) {
                    maxSimilarity = similarity;
                    mostSimilarSubmission = previous;
                }
            }

            // 将重复率更新到数据库
            BigDecimal duplicationRate = BigDecimal.valueOf(maxSimilarity * 100);
            current.setDuplicationRate(duplicationRate);
            updateById(current);

            // 打印日志（可选）
            System.out.printf("提交ID: %d, 最大重复率: %.2f%%, 最相似记录ID: %d%n",
                    current.getId(), duplicationRate, mostSimilarSubmission != null ? mostSimilarSubmission.getId() : null);
        }
    }

    @Override
    public Submissions getSubmissionByUserAndProblem(int loginIdAsInt, Integer problemId) {
        return getOne(new QueryWrapper<Submissions>().eq("user_id", loginIdAsInt).eq("problem_id", problemId));
    }


    @Override
    public Map<String, Object> getUserRankAndPercentage(Integer problemId, Integer userId) {
        // 获取该题目下所有 Accepted 的提交按运行时间排序
        List<Submissions> submissions = lambdaQuery()
                .eq(Submissions::getProblemId, problemId)
                .eq(Submissions::getStatus, "Accepted")
                .orderByAsc(Submissions::getRuntime)
                .list();

        int totalSubmissions = submissions.size(); // 总提交数
        System.out.println("totalSubmissions: " + totalSubmissions);

        // 如果没有任何 Accepted 提交
        if (totalSubmissions == 0) {
            return Map.of("rank", -1, "percentage", 0, "message", "该题目暂无 Accepted 的提交记录");
        }

        // 找到当前用户的排名和耗时
        int userRank = -1; // 用户排名初始化
        Integer userRuntime = null; // 用户提交的耗时
        for (int i = 0; i < totalSubmissions; i++) {
            if (submissions.get(i).getUserId().equals(userId)) {
                userRank = i + 1; // 排名从 1 开始
                userRuntime = submissions.get(i).getRuntime();
                break;
            }
        }

        // 如果用户没有 Accepted 提交，直接返回无排名
        if (userRank == -1) {
            return Map.of("rank", -1, "percentage", 0, "message", "用户没有 Accepted 的提交记录");
        }

        // 计算超越百分比
        // 如果只有一条记录，直接返回超越百分比 0
        if (totalSubmissions == 1) {
            return Map.of("rank", 1, "percentage", 0.0, "message", "只有一条 Accepted 的提交记录");
        }

        // 如果耗时相同的提交需要共享排名
        int equalRankCount = 0; // 记录耗时相同的提交数量
        int slowerCount = 0; // 耗时大于当前用户的提交数量

        for (Submissions submission : submissions) {
            if (submission.getRuntime().equals(userRuntime)) {
                equalRankCount++;
            } else if (submission.getRuntime() > userRuntime) {
                slowerCount++;
            }
        }

        // 用户的最终排名为第一个耗时相同记录的排名
        int adjustedRank = userRank;

        // 超越百分比为耗时大于当前用户的提交数所占比例
        double percentage = ((double) slowerCount / totalSubmissions) * 100;

        // 返回排名和超越百分比
        Map<String, Object> result = new HashMap<>();
        result.put("rank", adjustedRank);
        result.put("total", totalSubmissions);
        result.put("equalRankCount", equalRankCount); // 同一排名的数量（可选）
        result.put("percentage", percentage);
        result.put("message", "排名计算成功");

        return result;
    }


}
