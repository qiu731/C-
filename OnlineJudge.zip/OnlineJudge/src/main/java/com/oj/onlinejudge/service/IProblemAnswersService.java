package com.oj.onlinejudge.service;

import com.oj.onlinejudge.domain.po.ProblemAnswers;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 题目答案表 服务类
 * </p>
 *
 * @author flower
 * @since 2024-12-25
 */
public interface IProblemAnswersService extends IService<ProblemAnswers> {

    ProblemAnswers getByProblemID(Integer problemId);
}
