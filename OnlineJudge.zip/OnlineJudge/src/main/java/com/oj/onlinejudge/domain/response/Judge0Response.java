package com.oj.onlinejudge.domain.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/22 下午11:46
 */
@Data
public class Judge0Response {
    @JsonProperty("stdout")
    private String stdout;

    @JsonProperty("time")
    private String time;

    @JsonProperty("memory")
    private int memory;

    @JsonProperty("stderr")
    private String stderr;

    @JsonProperty("token")
    private String token;

    @JsonProperty("compile_output")
    private String compileOutput;

    @JsonProperty("message")
    private String message;

    @JsonProperty("status")
    private Status status;


    @Data
    public static class Status {
        @JsonProperty("id")
        private int id;

        @JsonProperty("description")
        private String description;

    }

}
