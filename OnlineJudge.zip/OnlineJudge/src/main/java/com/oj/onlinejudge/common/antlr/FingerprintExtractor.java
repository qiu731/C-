package com.oj.onlinejudge.common.antlr;

import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import org.antlr.v4.runtime.tree.ParseTree;

import java.nio.charset.StandardCharsets;
import java.util.*;

public class FingerprintExtractor {

    private static final int NUM_HASHES = 128; // MinHash 函数数量
    private static final List<HashFunction> HASH_FUNCTIONS = new ArrayList<>();

    static {
        for (int i = 0; i < NUM_HASHES; i++) {
            HASH_FUNCTIONS.add(Hashing.murmur3_32_fixed(i)); // 使用 MurmurHash3
        }
    }

    // 主接口 - 提取指纹
    public static int[] extractFingerprint(ParseTree node) {
        Set<String> shingles = new HashSet<>();
        computeShingles(node, shingles, 3); // 使用 3-gram
        return computeMinHash(shingles);
    }

    // 递归提取 AST 节点
    private static void computeShingles(ParseTree node, Set<String> shingles, int ngramSize) {
        if (node == null) return;

        // 创建基于类型和文本的 shingle
        StringBuilder sb = new StringBuilder();
        sb.append(node.getClass().getSimpleName()); // 节点类型
        sb.append(":");
        sb.append(node.getText()); // 节点文本

        for (int i = 0; i < node.getChildCount(); i++) {
            computeShingles(node.getChild(i), shingles, ngramSize);
            sb.append(node.getChild(i).getText());
        }

        // 生成 n-gram Shingles
        String text = sb.toString();
        for (int i = 0; i <= text.length() - ngramSize; i++) {
            shingles.add(text.substring(i, i + ngramSize));
        }
    }

    // 使用 MinHash 生成签名
    private static int[] computeMinHash(Set<String> shingles) {
        int[] minHashes = new int[NUM_HASHES];
        Arrays.fill(minHashes, Integer.MAX_VALUE); // 初始化为最大值

        for (String shingle : shingles) {
            for (int i = 0; i < NUM_HASHES; i++) {
                int hash = HASH_FUNCTIONS.get(i)
                        .hashString(shingle, StandardCharsets.UTF_8)
                        .asInt();
                minHashes[i] = Math.min(minHashes[i], hash); // 更新最小值
            }
        }
        return minHashes;
    }

    // 计算 Jaccard 相似度
    public static double computeSimilarity(int[] hash1, int[] hash2) {
        int matches = 0;
        for (int i = 0; i < NUM_HASHES; i++) {
            if (hash1[i] == hash2[i]) {
                matches++;
            }
        }
        return (double) matches / NUM_HASHES;
    }
}
