package com.oj.onlinejudge.config;

import cn.dev33.satoken.stp.StpInterface;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.oj.onlinejudge.domain.enums.Role;
import com.oj.onlinejudge.domain.po.Users;
import com.oj.onlinejudge.service.IUsersService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/27 上午10:31
 */
@Component
@RequiredArgsConstructor
// 保证此类被 SpringBoot 扫描，完成 Sa-Token 的自定义权限验证扩展
public class StpInterfaceImpl implements StpInterface {
    private final IUsersService usersService;
    /**
     * 返回一个账号所拥有的权限码集合
     */
    @Override
    public List<String> getPermissionList(Object loginId, String loginType) {
        // 本 list 仅做模拟，实际项目中要根据具体业务逻辑来查询权限
        List<String> list = new ArrayList<String>();
        list.add("101");
        list.add("user.add");
        list.add("user.update");
        list.add("user.get");
        // list.add("user.delete");
        list.add("art.*");
        return list;
    }

    /**
     * 返回一个账号所拥有的角色标识集合 (权限与角色可分开校验)
     */
    @Override
    public List<String> getRoleList(Object loginId, String loginType) {
        Users user = usersService.getOne(new QueryWrapper<Users>().eq("id", loginId));
        List<String> list = new ArrayList<String>();
        if (user != null) {
            // 检查 user.getRole() 是否为 null
            if (user.getRole() != null) {
                // 使用三元运算符添加角色
                list.add(user.getRole().equals(Role.TEACHER) ? "teacher" : "student");
            } else {
                // 如果 role 为 null，可以处理这种情况，例如添加默认角色或抛出异常
                list.add("default-role"); // 或者抛出异常
            }
        } else {
            // 如果 user 为 null，可以处理这种情况，例如添加默认角色或抛出异常
            list.add("default-role"); // 或者抛出异常
        }
        System.out.println("该账户角色是"+list);
        return list;
    }

}
