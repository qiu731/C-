package com.oj.onlinejudge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemComments;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 题目评论表 服务类
 * </p>
 *
 * @author flower
 * @since 2024-12-23
 */
public interface IProblemCommentsService extends IService<ProblemComments> {

    boolean addComment(ProblemComments comment);

    boolean deleteCommentById(Integer id);

    List<ProblemComments> getCommentsByProblemId(Integer problemId);

    Page<ProblemComments> adminGetCommentsPage(Page<ProblemComments> page, String query);
}
