package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.annotation.SaCheckRole;
import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemSamples;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.service.IProblemSamplesService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 题目示例表 前端控制器
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@RestController
@RequestMapping("/problem-samples")
@RequiredArgsConstructor
@Validated
@Api(tags = "题目示例管理接口") // 描述整个控制器
public class ProblemSamplesController {

    private final IProblemSamplesService pService;

    @SaCheckLogin
    @SaCheckRole("teacher")
    @PostMapping("/create")
    @ApiOperation(value = "创建题目示例", notes = "需要教师权限")
    @ApiImplicitParam(name = "problems", value = "题目示例对象", required = true, dataType = "ProblemSamples", paramType = "body")
    public ApiResponse<Boolean> createProblem(@RequestBody ProblemSamples problems) {
        boolean problemId = pService.createSample(problems);
        if (problems.getProblemId() == null || problems.getProblemId() == 0){
            return ApiResponse.failure(400, "创建失败题目id不能为空");
        }
        if(problemId){
            return ApiResponse.success(problemId);
        }else {
            return ApiResponse.failure(400, "创建失败");
        }
    }

    @GetMapping("/getByProblemId/{problemId}")
    @ApiOperation(value = "根据题目ID获取示例列表", notes = "返回指定题目的所有示例")
    @ApiImplicitParam(name = "problemId", value = "题目ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<List<ProblemSamples>> getSamplesByProblemId(@PathVariable Integer problemId) {
        List<ProblemSamples> problemSamples = pService.getSamplesByProblemId(problemId);
        return ApiResponse.success(problemSamples);
    }

    @GetMapping("/page")
    @ApiOperation(value = "分页查询题目示例", notes = "支持分页和模糊查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页码，默认值为1", defaultValue = "1", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "每页大小，默认值为10", defaultValue = "10", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "query", value = "查询关键字", required = false, dataType = "String", paramType = "query")
    })
    public ApiResponse<Page<ProblemSamples>> getAllProblems(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query) {
        Page<ProblemSamples> page = new Page<>(current, size);
        Page<ProblemSamples> problemSamples = pService.getSamplesByPage(page, query);
        return ApiResponse.success(problemSamples);
    }

    @DeleteMapping("/deleteById/{id}")
    @ApiOperation(value = "删除题目示例", notes = "通过ID删除指定的题目示例")
    @ApiImplicitParam(name = "id", value = "题目示例ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<Boolean> deleteProblem(@PathVariable Integer id) {
        boolean problemId = pService.deleteSampleById(id);
        return ApiResponse.success(problemId);
    }

    @PutMapping("/updateById")
    @Transactional
    @ApiOperation(value = "更新题目示例", notes = "通过ID更新指定的题目示例")
    @ApiImplicitParam(name = "problemSamples", value = "题目示例对象", required = true, dataType = "ProblemSamples", paramType = "body")
    public ApiResponse<Boolean> updateProblem(@RequestBody ProblemSamples problemSamples) {
        boolean problemId = pService.updateSample(problemSamples);
        if (problemId){
            return ApiResponse.success(true);
        }
        return ApiResponse.failure(400, "更新失败");
    }
}