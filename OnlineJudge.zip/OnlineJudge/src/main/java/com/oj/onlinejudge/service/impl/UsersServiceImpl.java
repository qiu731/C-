package com.oj.onlinejudge.service.impl;

import cn.dev33.satoken.stp.SaTokenInfo;
import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.enums.Role;
import com.oj.onlinejudge.domain.po.Submissions;
import com.oj.onlinejudge.domain.po.Users;
import com.oj.onlinejudge.domain.vo.UserLoginVO;
import com.oj.onlinejudge.mapper.UsersMapper;
import com.oj.onlinejudge.service.ISubmissionsService;
import com.oj.onlinejudge.service.IUsersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@Service
@RequiredArgsConstructor
public class UsersServiceImpl extends ServiceImpl<UsersMapper, Users> implements IUsersService {

    private final PasswordEncoder passwordEncoder;
    private final UsersMapper usersMapper;
    private final ISubmissionsService submissionsService;
    @Transactional
    @Override
    public boolean register(Users users) {
        // 验证输入参数
        if (users.getUsername() == null || users.getPassword() == null || users.getEmail() == null || users.getStudentNumber() == null) {
            throw new IllegalArgumentException("用户名、密码、邮箱和学号不能为空！");
        }

        // 检查用户名是否重复
        if (lambdaQuery().eq(Users::getUsername, users.getUsername()).count() > 0) {
            throw new IllegalArgumentException("用户名已存在！");
        }

        // 检查邮箱是否重复
        if (lambdaQuery().eq(Users::getEmail, users.getEmail()).count() > 0) {
            throw new IllegalArgumentException("邮箱已被注册！");
        }

        // 检查学号是否重复
        if (lambdaQuery().eq(Users::getStudentNumber, users.getStudentNumber()).count() > 0) {
            throw new IllegalArgumentException("学号已被注册！");
        }

        // 密码加密
        String encodedPassword = passwordEncoder.encode(users.getPassword());
        users.setPassword(encodedPassword);

        // 设置默认值
        users.setId(null);
        users.setLevel(1);
        users.setLastLogin(null);
        users.setRole(Role.STUDENT);
        users.setCreatedAt(LocalDateTime.now());
        users.setUpdatedAt(LocalDateTime.now());

        // 保存用户信息
        return save(users);
    }


    @Override
    public UserLoginVO login(String username, String password) {
    // 查询用户信息
    Users user = getOne(new QueryWrapper<Users>().eq("username", username));
        LocalDateTime lastLogin = user.getLastLogin();
        System.out.println("lastLogin"+lastLogin);
        if (passwordEncoder.matches(password, user.getPassword())) {
            UserLoginVO userLoginVO = BeanUtil.copyProperties(user, UserLoginVO.class);
        // 更新最后登录时间
            user.setLastLogin(LocalDateTime.now());
            updateById(user);
            System.out.println("lastLogin2"+lastLogin);
            user.setLastLogin(lastLogin);
            user.setPassword(null);
            StpUtil.login(user.getId());
            SaTokenInfo tokenInfo = StpUtil.getTokenInfo();
            userLoginVO.setSatoken(tokenInfo.getTokenValue());
            userLoginVO.setPassRate(user.getSuccessfulSubmissions() / (float) user.getTotalSubmissions());
            return userLoginVO;
    }

    return null;
}

    @Transactional
    @Override
    public void incrementTotalSubmissions(int userId) {
        usersMapper.incrementTotalSubmissions(userId);
    }

    @Transactional
    @Override
    public void incrementSuccessfulSubmissions(int userId) {
        incrementTotalSubmissions(userId);
        usersMapper.incrementSuccessfulSubmissions(userId);
    }

    @Override
    public Users getUserById(int userId) {
        return getById(userId);
    }
    @Transactional
    @Override
    public boolean updateUser(Users users) {
        // 获取当前用户的原始数据
        Users existingUser = getById(users.getId());
        if (existingUser == null) {
            throw new RuntimeException("用户不存在");
        }

        // 校验用户名是否重复（排除当前用户）
        boolean isUsernameDuplicate = lambdaQuery()
                .eq(Users::getUsername, users.getUsername())
                .ne(Users::getId, users.getId())
                .count() > 0;
        if (isUsernameDuplicate) {
            throw new RuntimeException("用户名已存在");
        }

        // 校验邮箱是否重复（排除当前用户）
        boolean isEmailDuplicate = lambdaQuery()
                .eq(Users::getEmail, users.getEmail())
                .ne(Users::getId, users.getId())
                .count() > 0;
        if (isEmailDuplicate) {
            throw new RuntimeException("邮箱已存在");
        }

        // 校验学号是否重复（排除当前用户）
        boolean isStudentNumberDuplicate = lambdaQuery()
                .eq(Users::getStudentNumber, users.getStudentNumber())
                .ne(Users::getId, users.getId())
                .count() > 0;
        if (isStudentNumberDuplicate) {
            throw new RuntimeException("学号已存在");
        }

        // 如果密码发生变化，进行加密处理
        if (!existingUser.getPassword().equals(users.getPassword())) {
            String encodedPassword = passwordEncoder.encode(users.getPassword());
            users.setPassword(encodedPassword);
        }

        // 更新用户信息
        return updateById(users);
    }

    @Transactional
    @Override
    public boolean deleteUserById(int userId) {
        return removeById(userId);
    }

    @Override
    public long countUsers() {
        return count();
    }

    @Override
    public List<Users> getRecentUsers(int limit) {
        return list(new QueryWrapper<Users>().orderByDesc("last_login").last("LIMIT " + limit));
    }

    @Override
    public boolean addByPoints(int userId, int i) {
        Users users = getById(userId);
        if (users.getPoints()!=null){
            users.setPoints(users.getPoints()+i);
        }else {
            users.setPoints(i);
        }
        return updateById(users);
    }

    @Override
    public boolean addByTotalScore(Integer userId, Integer score) {
        if (userId != null && score != null) {
            Users users = getById(userId);
            users.setTotalScore(users.getTotalScore() + score);
            return updateById(users);
        }
        return false;
    }

    @Override
    public Page<Users> getAllUsers(Page<Users> page, String query) {
        if (query != null && !query.isEmpty()) {
            return page(page, new QueryWrapper<Users>()
                    .like("username", query)
                    .or()
                    .like("student_number", query)
            );
        }
        return page(page, new QueryWrapper<Users>());
    }


    @Override
    public List<Users> getTopPassUsers(int limit) {
        return usersMapper.selectList(new QueryWrapper<Users>()
                .ne("role", "teacher")
                .orderByDesc("successful_submissions")
                .last("limit " + limit));
    }

    @Override
    public List<Users> getTopAccuracyUsers(int limit) {
        return usersMapper.selectList(new QueryWrapper<Users>()
                .ne("role", "teacher")
                .select("*, (successful_submissions * 1.0 / total_submissions) as accuracy")
                .orderByDesc("accuracy")
                .last("limit " + limit));
    }

    @Override
    public List<Users> getTopScoreUsers(int limit) {
        return usersMapper.selectList(new QueryWrapper<Users>()
                .ne("role", "teacher")
                .orderByDesc("total_score")
                .last("limit " + limit));
    }

    @Override
    public boolean addlevel(Integer userId, int i) {
        if (userId != null) {
            Users users = getById(userId);
            users.setLevel(users.getLevel() + i);
            return updateById(users);
        }
        return false;
    }
    @Override
    public boolean totalScore(Integer userId) {
        // 查询该用户所有提交记录，过滤掉分数为 null 的记录
        List<Submissions> submissions = submissionsService.lambdaQuery()
                .eq(Submissions::getUserId, userId) // 筛选指定用户
                .isNotNull(Submissions::getScore) // 过滤掉分数为 null 的提交
                .list();

        // 如果没有有效的提交记录，直接返回 false
        if (submissions == null || submissions.isEmpty()) {
            return false;
        }

        // 计算总分
        int totalScore = submissions.stream()
                .mapToInt(Submissions::getScore) // 提取分数
                .sum(); // 累加

        // 更新用户的总分字段

        return lambdaUpdate()
                .eq(Users::getId, userId) // 根据用户 ID 更新
                .set(Users::getTotalScore, totalScore) // 更新 totalScore 字段
                .update();

    }

    @Override
    @Transactional
    public boolean removeBatchByIds(List<Integer> ids) {
        return removeByIds(ids);
    }


}
