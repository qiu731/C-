package com.oj.onlinejudge.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemSamples;
import com.oj.onlinejudge.domain.po.Problems;
import com.oj.onlinejudge.domain.vo.ProblemVO;
import com.oj.onlinejudge.mapper.ProblemsMapper;
import com.oj.onlinejudge.service.IProblemSamplesService;
import com.oj.onlinejudge.service.IProblemsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 题目表 服务实现类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@Service
@RequiredArgsConstructor
public class ProblemsServiceImpl extends ServiceImpl<ProblemsMapper, Problems> implements IProblemsService {

    private final IProblemSamplesService iProblemsService;
    @Transactional
    @Override
    public Integer createProblem(Problems problems) {
        // 设置默认值或进行其他处理
        problems.setCreatedAt(LocalDateTime.now());
        problems.setUpdatedAt(LocalDateTime.now());
        save(problems); // MyBatis-Plus会自动处理ID生成
        return problems.getId();
    }
    @Transactional
    @Override
    public boolean updateProblem(Problems problems) {
        problems.setUpdatedAt(LocalDateTime.now());
        return updateById(problems);
    }
    @Transactional
    @Override
    public boolean deleteProblemById(Integer id) {
        return removeById(id);
    }
    @Override
    public Page<Problems> getProblemsByPage(Page<Problems> page, String keyword, String difficulty) {
        // 创建查询条件
        QueryWrapper<Problems> queryWrapper = new QueryWrapper<>();

        // 添加关键字查询条件
        if (keyword != null && !keyword.trim().isEmpty()) {
            queryWrapper.lambda().and(wrapper ->
                    wrapper.like(Problems::getTitle, keyword)
                            .or()
                            .like(Problems::getDescription, keyword)
            );
        }

        // 添加难度筛选条件
        if (difficulty != null && !difficulty.trim().isEmpty()) {
            queryWrapper.lambda().eq(Problems::getDifficulty, difficulty);
        }

        System.out.println("queryWrapper: keyword=" + keyword + ", difficulty=" + difficulty);

        // 执行分页查询
        return page(page, queryWrapper);
    }



    @Override
    public ProblemVO getProblemById(Integer id) {
        List<ProblemSamples> problemById = iProblemsService.getSamplesByProblemId(id);
        Problems byId = getById(id);
        ProblemVO problemVO = BeanUtil.copyProperties(byId, ProblemVO.class);
        problemVO.setSamples(problemById);
        return problemVO;
    }

    @Override
    public List<Problems> getAllProblems() {
        return list();
    }
    @Override
    public long countProblems() {
        return count(); // 使用 MyBatis-Plus 提供的统计功能
    }

    @Override
    public List<Problems> getRecentProblems(int limit) {
        return list(new QueryWrapper<Problems>().orderByDesc("created_at").last("LIMIT " + limit));
    }

    @Override
    public IPage<Problems> getProblemsByPageByUser(Page<Problems> page, String keyword, String difficulty) {
        QueryWrapper<Problems> queryWrapper = new QueryWrapper<>();

        // 添加关键字查询条件
        if (keyword != null && !keyword.trim().isEmpty()) {
            queryWrapper.lambda().and(wrapper ->
                    wrapper.like(Problems::getTitle, keyword)
                            .or()
                            .like(Problems::getDescription, keyword)
            );
        }

        // 添加难度筛选条件
        if (difficulty != null && !difficulty.trim().isEmpty()) {
            queryWrapper.lambda().eq(Problems::getDifficulty, difficulty);
        }
        queryWrapper.lambda().eq(Problems::getVisible, true);

        System.out.println("queryWrapper: keyword=" + keyword + ", difficulty=" + difficulty);

        // 执行分页查询
        return page(page, queryWrapper);
    }


}
