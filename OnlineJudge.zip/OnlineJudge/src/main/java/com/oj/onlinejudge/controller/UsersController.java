package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.domain.po.Users;
import com.oj.onlinejudge.domain.vo.UserLoginVO;
import com.oj.onlinejudge.service.IUsersService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@Api(tags = "用户管理接口") // 描述整个控制器
public class UsersController {

    private static final Logger log = LoggerFactory.getLogger(UsersController.class);
    private final IUsersService usersService;

    @PostMapping("/student/register")
    @ApiOperation(value = "学生注册", notes = "允许新学生用户注册")
    @ApiImplicitParam(name = "users", value = "用户对象", required = true, dataType = "Users", paramType = "body")
    public ApiResponse<?> register(@RequestBody Users users) {
        System.out.println("register" + users);
        boolean result = usersService.register(users);
        if (result) {
            return ApiResponse.success(Map.of("message", "注册成功"));
        } else {
            return ApiResponse.failure(400, "注册失败");
        }
    }

    @PostMapping("/login")
    @ApiOperation(value = "用户登录", notes = "验证用户名和密码并返回用户信息")
    @ApiImplicitParam(name = "users", value = "用户对象（仅需包含用户名和密码）", required = true, dataType = "Users", paramType = "body")
    public ApiResponse<?> login(@RequestBody Users users) {
        UserLoginVO user = usersService.login(users.getUsername(), users.getPassword());
        if (user != null) {
            return ApiResponse.success(Map.of("message", "登录成功", "user", user));
        } else {
            return ApiResponse.failure(400, "用户名或密码错误");
        }
    }

    @GetMapping("/page")
    @ApiOperation(value = "分页查询用户列表", notes = "支持分页和模糊查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页码，默认值为1", defaultValue = "1", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "每页大小，默认值为10", defaultValue = "10", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "query", value = "查询关键字", required = false, dataType = "String", paramType = "query")
    })
    public ApiResponse<?> getAllUsers(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query) {
        Page<Users> page = new Page<>(current, size);
        Page<Users> users = usersService.getAllUsers(page, query);
        return ApiResponse.success(users);
    }

    @GetMapping("/getUserById/{id}")
    @ApiOperation(value = "根据ID获取用户信息", notes = "通过用户ID查询用户详细信息")
    @ApiImplicitParam(name = "id", value = "用户ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<?> getUserById(@PathVariable Integer id) {
        Users user = usersService.getUserById(id);
        if (user != null) {
            return ApiResponse.success(Map.of("message", "查询成功", "user", user));
        } else {
            return ApiResponse.failure(400, "用户不存在");
        }
    }

    @GetMapping("/getUserByLogin")
    @SaCheckLogin
    @ApiOperation(value = "根据ID获取用户信息", notes = "通过用户ID查询用户详细信息")
    @ApiImplicitParam(name = "id", value = "用户ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<?> getUserByLogin() {

        Users user = usersService.getUserById(StpUtil.getLoginIdAsInt());
        if (user != null) {
            return ApiResponse.success(Map.of("message", "查询成功", "user", user));
        } else {
            return ApiResponse.failure(400, "用户不存在");
        }
    }

    @PutMapping("/updateUser")
    @Transactional
    @ApiOperation(value = "更新用户信息", notes = "通过用户ID更新指定用户的详细信息")
    @ApiImplicitParam(name = "users", value = "用户对象（需要包含所有字段，包括不变的字段）", required = true, dataType = "Users", paramType = "body")
    public ApiResponse<?> updateUser(@RequestBody Users users) {
        Users existingUser = usersService.getUserById(users.getId());
        if (existingUser == null) {
            return ApiResponse.failure(400, "用户不存在");
        }
        users.setRole(existingUser.getRole());
        users.setLevel(existingUser.getLevel());
        users.setCreatedAt(existingUser.getCreatedAt());
        users.setUpdatedAt(LocalDateTime.now());
        users.setTotalSubmissions(existingUser.getTotalSubmissions());
        users.setTotalScore(existingUser.getTotalScore());
        users.setPoints(existingUser.getPoints());
        users.setSuccessfulSubmissions(existingUser.getSuccessfulSubmissions());
        boolean result = usersService.updateUser(users);
        if (result) {
            return ApiResponse.success(Map.of("message", "更新成功"));
        } else {
            return ApiResponse.failure(400, "更新失败");
        }
    }

    @PutMapping("/addByPoints")
    @Transactional
    @ApiOperation(value = "增加用户积分", notes = "通过用户ID增加指定用户的积分")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户ID", required = true, dataType = "Integer", paramType = "path"),
            @ApiImplicitParam(name = "i", value = "要增加的积分值", required = true, dataType = "Integer", paramType = "query")
    })
    public ApiResponse<?> addByPoints(@RequestParam Integer id, @RequestParam Integer i) {
        boolean result = usersService.addByPoints(id, i);
        if (result) {
            return ApiResponse.success(Map.of("message", "增加成功"));
        } else {
            return ApiResponse.failure(400, "增加失败");
        }
    }

    @DeleteMapping("/deleteUserById/{id}")
    @Transactional
    @ApiOperation(value = "删除用户", notes = "通过用户ID删除指定用户")
    @ApiImplicitParam(name = "id", value = "用户ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<?> deleteUserById(@PathVariable Integer id) {
        boolean result = usersService.deleteUserById(id);
        if (result) {
            return ApiResponse.success(Map.of("message", "删除成功"));
        } else {
            return ApiResponse.failure(400, "删除失败");
        }
    }

    @GetMapping("/getRecentUsers")
    @ApiOperation(value = "获取最近注册的用户", notes = "获取最近注册的用户列表")
    @ApiImplicitParam(name = "limit", value = "要获取的用户数量", required = true, dataType = "Integer", paramType = "query")
    public ApiResponse<?> getRecentUsers(@RequestParam int limit) {
        List<Users> users = usersService.getRecentUsers(limit);
        return ApiResponse.success(users);
    }

    @DeleteMapping("/deleteBatch")
    @Transactional
    @ApiOperation(value = "批量删除用户", notes = "根据ID列表批量删除用户")
    @ApiImplicitParam(name = "ids", value = "用户ID列表", required = true, dataType = "List<Integer>", paramType = "body")
    public ApiResponse<?> deleteUsersBatch(@RequestBody List<Integer> ids) {
        try {
            if (ids == null || ids.isEmpty()) {
                return ApiResponse.failure(400, "ID列表不能为空");
            }
            boolean result = usersService.removeBatchByIds(ids);
            if (result) {
                log.info("成功删除用户: {}", ids);
                return ApiResponse.success(Map.of("message", "删除成功"));
            } else {
                log.warn("尝试删除用户失败: {}", ids);
                return ApiResponse.failure(500, "删除失败，请检查日志或联系管理员");
            }
        } catch (Exception e) {
            log.error("删除用户时发生错误: {}", e.getMessage(), e);
            return ApiResponse.failure(500, "服务器内部错误");
        }
    }
}