package com.oj.onlinejudge.mapper;

import com.oj.onlinejudge.domain.po.ProblemAnswers;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 题目答案表 Mapper 接口
 * </p>
 *
 * @author flower
 * @since 2024-12-25
 */
public interface ProblemAnswersMapper extends BaseMapper<ProblemAnswers> {

}
