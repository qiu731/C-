package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.annotation.SaCheckRole;
import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.domain.po.Problems;
import com.oj.onlinejudge.domain.vo.ProblemVO;
import com.oj.onlinejudge.service.IProblemsService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 题目控制类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
@RestController
@RequestMapping("/problems")
@RequiredArgsConstructor
@Validated
@Api(tags = "题目管理接口") // 描述整个控制器
public class ProblemsController {

    private static final Logger log = LoggerFactory.getLogger(ProblemsController.class);
    private final IProblemsService problemsService;

    @SaCheckLogin
    @SaCheckRole("teacher")
    @PostMapping("/create")
    @ApiOperation(value = "创建新题目", notes = "需要教师权限")
    @ApiImplicitParam(name = "problems", value = "题目对象", required = true, dataType = "Problems", paramType = "body")
    public ApiResponse<Integer> createProblem(@RequestBody Problems problems) {
        Object loginId = StpUtil.getLoginId();
        problems.setCreatedBy(Integer.parseInt(loginId.toString()));
        Integer problemId = problemsService.createProblem(problems);
        return ApiResponse.success(problemId);
    }

    @PutMapping("/updateById")
    @ApiOperation(value = "更新题目信息", notes = "通过ID更新指定题目的信息")
    @ApiImplicitParam(name = "problems", value = "题目对象（需包含ID）", required = true, dataType = "Problems", paramType = "body")
    public ApiResponse<Boolean> updateProblem(@RequestBody Problems problems) {
        boolean updated = problemsService.updateProblem(problems);
        if (updated) {
            return ApiResponse.success(true);
        } else {
            return ApiResponse.failure(400, "更新失败");
        }
    }


    @DeleteMapping("/deleteById/{id}")
    @ApiOperation(value = "删除题目", notes = "通过ID删除指定题目")
    @ApiImplicitParam(name = "id", value = "题目ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<Boolean> deleteProblem(@PathVariable Integer id) {
        boolean deleted = problemsService.deleteProblemById(id);
        if (deleted) {
            return ApiResponse.success(true);
        } else {
            return ApiResponse.failure(404, "题目不存在或删除失败");
        }
    }

    @GetMapping("/getAll")
    @ApiOperation(value = "获取所有题目", notes = "返回系统中所有的题目列表")
    public ApiResponse<List<Problems>> getAllProblems() {
        List<Problems> problems = problemsService.getAllProblems();
        return ApiResponse.success(problems);
    }


    @GetMapping("/getById/{id}")
    @ApiOperation(value = "根据ID获取题目", notes = "通过题目ID查询并返回题目详细信息")
    @ApiImplicitParam(name = "id", value = "题目ID", required = true, dataType = "Integer", paramType = "path")
    public ApiResponse<ProblemVO> getProblemById(@PathVariable Integer id) {
        ProblemVO problem = problemsService.getProblemById(id);
        if (problem != null) {
            return ApiResponse.success(problem);
        } else {
            return ApiResponse.failure(404, "题目不存在");
        }
    }


    @GetMapping("/page")
    @ApiOperation(value = "分页查询题目", notes = "支持分页和模糊查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页码，默认值为1", defaultValue = "1", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "每页大小，默认值为10", defaultValue = "10", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "query", value = "查询关键字", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "difficulty", value = "题目难度（简单、中等、困难）", required = false, dataType = "String", paramType = "query")

    })
    public ApiResponse<IPage<Problems>> getProblemsByPage(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String difficulty) {
        Page<Problems> page = new Page<>(current, size);
        System.out.println("query = " + query);
        System.out.println("difficulty = " + difficulty);
        IPage<Problems> resultPage = problemsService.getProblemsByPage(page, query, difficulty);
        return ApiResponse.success(resultPage);
    }


    @GetMapping("/page/user")
    @ApiOperation(value = "分页查询题目", notes = "支持分页和模糊查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页码，默认值为1", defaultValue = "1", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "size", value = "每页大小，默认值为10", defaultValue = "10", dataType = "int", paramType = "query"),
            @ApiImplicitParam(name = "query", value = "查询关键字", required = false, dataType = "String", paramType = "query"),
            @ApiImplicitParam(name = "difficulty", value = "题目难度（简单、中等、困难）", required = false, dataType = "String", paramType = "query")

    })
    public ApiResponse<IPage<Problems>> getProblemsByPageByUser(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String difficulty) {
        Page<Problems> page = new Page<>(current, size);
        System.out.println("query = " + query);
        System.out.println("difficulty = " + difficulty);
        IPage<Problems> resultPage = problemsService.getProblemsByPageByUser(page, query, difficulty);
        return ApiResponse.success(resultPage);
    }

    @PostMapping("/deleteBatch")
    @ApiOperation(value = "批量删除题目", notes = "通过ID列表批量删除题目")
    @ApiImplicitParam(name = "ids", value = "题目ID列表", required = true, dataType = "List", paramType = "body")
    public ApiResponse<Boolean> deleteProblemsBatch(@RequestBody List<Integer> ids) {
//        System.out.println("ids = " + ids);
        try {
            if (ids == null || ids.isEmpty()) {
                return ApiResponse.failure(400, "ID列表不能为空");
            }
            boolean deleted = problemsService.removeByIds(ids);
//            boolean deleted = true;
            if (deleted) {
                return ApiResponse.success(true);
            } else {
                return ApiResponse.failure(400, "删除失败");
            }
        } catch (Exception e) {
            log.error("删除题目时发生错误: {}", e.getMessage(), e);
            return ApiResponse.failure(500, "服务器内部错误");
        }
    }
}