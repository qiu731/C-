package com.oj.onlinejudge.domain.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 题目评论表
 * </p>
 *
 * @author flower
 * @since 2024-12-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("problem_comments")
@ApiModel(value="ProblemComments对象", description="题目评论表")
public class ProblemComments implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "题目的 ID")
    private Integer problemId;

    @ApiModelProperty(value = "评论者的用户 ID")
    private Integer userId;

    @ApiModelProperty(value = "评论内容")
    private String comment;

    @ApiModelProperty(value = "评论创建时间")
    private LocalDateTime createdAt;

    @ApiModelProperty(value = "评论更新时间")
    private LocalDateTime updatedAt;

    @ApiModelProperty(value = "评论者的用户名")
    private String username;

    @ApiModelProperty(value = "题目标题")
    private String problemTitle;


}
