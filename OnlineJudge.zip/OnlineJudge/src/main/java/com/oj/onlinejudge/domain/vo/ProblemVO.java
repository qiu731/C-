package com.oj.onlinejudge.domain.vo;

import com.oj.onlinejudge.domain.po.ProblemSamples;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/29 下午4:52
 */
@Data
public class ProblemVO {

    private Integer id;

    @ApiModelProperty(value = "题目标题")
    private String title;

    @ApiModelProperty(value = "题目描述")
    private String description;

    @ApiModelProperty(value = "输入描述")
    private String inputDescription;

    @ApiModelProperty(value = "输出描述")
    private String outputDescription;

    @ApiModelProperty(value = "时间限制（毫秒）")
    private Integer timeLimit;

    @ApiModelProperty(value = "内存限制（KB）")
    private Integer memoryLimit;

    @ApiModelProperty(value = "题目难度")
    private String difficulty;

    @ApiModelProperty(value = "题目标签")
    private String tags;

    @ApiModelProperty(value = "题目是否对所有用户可见")
    private Boolean visible;

    @ApiModelProperty(value = "创建者用户的 ID")
    private Integer createdBy;

    @ApiModelProperty(value = "题目创建时间")
    private LocalDateTime createdAt;

    @ApiModelProperty(value = "题目更新时间")
    private LocalDateTime updatedAt;

    @ApiModelProperty(value = "题目示例")
    private List<ProblemSamples> samples;
}
