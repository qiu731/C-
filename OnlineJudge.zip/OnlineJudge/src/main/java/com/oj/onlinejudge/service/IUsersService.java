package com.oj.onlinejudge.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.Users;
import com.baomidou.mybatisplus.extension.service.IService;
import com.oj.onlinejudge.domain.vo.UserLoginVO;

import java.util.List;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
public interface IUsersService extends IService<Users> {
    boolean register(Users users);
    UserLoginVO login(String username, String password);
    void incrementTotalSubmissions(int userId);
    void incrementSuccessfulSubmissions(int userId);
    Users getUserById(int userId);
    boolean updateUser(Users users);
    boolean deleteUserById(int userId);

    long countUsers();

    List<Users> getRecentUsers(int limit);

    boolean addByPoints(int userId, int i);

    boolean addByTotalScore(Integer userId, Integer score);

    Page<Users> getAllUsers(Page<Users> page, String query);

    List<Users> getTopPassUsers(int limit);

    List<Users> getTopAccuracyUsers(int limit);

    List<Users> getTopScoreUsers(int limit);

    boolean addlevel(Integer userId, int i);

    boolean totalScore(Integer userId);

    boolean removeBatchByIds(List<Integer> ids);
}
