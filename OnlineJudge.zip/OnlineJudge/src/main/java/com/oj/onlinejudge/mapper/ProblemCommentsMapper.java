package com.oj.onlinejudge.mapper;

import com.oj.onlinejudge.domain.po.ProblemComments;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 题目评论表 Mapper 接口
 * </p>
 *
 * @author flower
 * @since 2024-12-23
 */
public interface ProblemCommentsMapper extends BaseMapper<ProblemComments> {

}
