package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.annotation.SaCheckRole;
import cn.dev33.satoken.stp.StpUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oj.onlinejudge.domain.po.ProblemAnswers;
import com.oj.onlinejudge.domain.po.Problems;
import com.oj.onlinejudge.domain.po.Submissions;
import com.oj.onlinejudge.domain.po.Users;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.service.IProblemAnswersService;
import com.oj.onlinejudge.service.IProblemsService;
import com.oj.onlinejudge.service.ISubmissionsService;
import com.oj.onlinejudge.service.IUsersService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 题目答案表 前端控制器
 * </p>
 *
 * @author flower
 * @since 2024-12-25
 */
@RestController
@RequestMapping("/problem-answers")
@RequiredArgsConstructor
public class ProblemAnswersController {

    private final IProblemAnswersService problemAnswerService;
    private final IUsersService userService;
    private final IProblemsService problemService;
    private final ISubmissionsService submissionService;


    @PostMapping("/create")
    @SaCheckLogin
    @SaCheckRole("teacher")
    public ApiResponse<?> addAnswer(@RequestBody ProblemAnswers answer) {
        Object loginId = StpUtil.getLoginId();
        Users user = userService.getById(Integer.parseInt(loginId.toString()));
        Problems problem = problemService.getById(answer.getProblemId());
        answer.setUsername(user.getUsername());
        answer.setProblemTitle(problem.getTitle());
        answer.setCreatedBy(Integer.parseInt(loginId.toString()));
        answer.setCreatedAt(LocalDateTime.now());
        answer.setUpdatedAt(LocalDateTime.now());
        boolean result = problemAnswerService.save(answer);
        return result ? ApiResponse.success("答案添加成功") : ApiResponse.failure(500, "答案添加失败");
    }


    @GetMapping("/page")
    @SaCheckLogin
    @SaCheckRole("teacher")
    public ApiResponse<?> getAnswersPage(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query) {
        Page<ProblemAnswers> page = new Page<>(current, size);
        Page<ProblemAnswers> answersPage = problemAnswerService.lambdaQuery()
                .like(query != null && !query.isEmpty(), ProblemAnswers::getProblemTitle, query)
                .orderByDesc(ProblemAnswers::getCreatedAt)
                .page(page);
        return ApiResponse.success(answersPage);
    }

    @GetMapping("/page/{id}")
    @SaCheckLogin
    @SaCheckRole("teacher")
    public ApiResponse<?> getAnswersPageByProblemId(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query,
            @PathVariable Integer id
            ) {
        Page<ProblemAnswers> page = new Page<>(current, size);
        Page<ProblemAnswers> answersPage = problemAnswerService.lambdaQuery()
                .like(query != null && !query.isEmpty(), ProblemAnswers::getProblemTitle, query)
                .orderByDesc(ProblemAnswers::getCreatedAt)
                .eq(ProblemAnswers::getProblemId, id)
                .page(page);
        return ApiResponse.success(answersPage);
    }

    @PutMapping("/update")
    @SaCheckLogin
    @SaCheckRole("teacher")
    public ApiResponse<?> updateAnswer(@RequestBody ProblemAnswers answer) {
        answer.setUpdatedAt(LocalDateTime.now());
        boolean result = problemAnswerService.updateById(answer);
        return result ? ApiResponse.success("答案更新成功") : ApiResponse.failure(500, "答案更新失败");
    }

    @DeleteMapping("/{id}")
    @SaCheckLogin
    @SaCheckRole("teacher")
    public ApiResponse<?> deleteAnswer(@PathVariable Integer id) {
        boolean result = problemAnswerService.removeById(id);
        return result ? ApiResponse.success("答案删除成功") : ApiResponse.failure(500, "答案删除失败");
    }

    @PostMapping("/deleteBatch")
    @SaCheckLogin
    @SaCheckRole("teacher")
    public ApiResponse<?> deleteAnswersBatch(@RequestBody List<Integer> ids) {
        boolean result = problemAnswerService.removeByIds(ids);
        return result ? ApiResponse.success("批量删除成功") : ApiResponse.failure(500, "批量删除失败");
    }

    @GetMapping("/getById/{id}")
    public ApiResponse<?> getAnswerById(@PathVariable Integer id) {
        ProblemAnswers answer = problemAnswerService.getById(id);
        if (answer == null){
            return ApiResponse.error(404, "暂无答案");
        }
        return ApiResponse.success(answer);
    }

    @ApiOperation(value = "查找提交", notes = "根据用户登录信息和题目id查找提交")
    @SaCheckLogin
    @GetMapping("/getSubmit")
    public ApiResponse<?> getSubmit(@RequestParam Integer problemId) {
        Object loginId = StpUtil.getLoginId();
        Submissions submissions = submissionService.getSubmissionByUserAndProblem(StpUtil.getLoginIdAsInt(), problemId);
        if(
                submissions == null ||
                        submissions.getStatus().equals("Failed") ||
                        !submissions.getStatus().equals("Accepted")
        ){
            return ApiResponse.error(404, "暂无提交或提交未通过");
        }
        ProblemAnswers answer = problemAnswerService.getByProblemID(problemId);
        if (answer == null){
            return ApiResponse.error(10086, "暂无答案");
        }
        return ApiResponse.success(answer);
    }
}
