package com.oj.onlinejudge.controller;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.stp.StpUtil;
import com.oj.onlinejudge.domain.enums.Role;
import com.oj.onlinejudge.domain.po.ProblemComments;
import com.oj.onlinejudge.domain.po.Users;
import com.oj.onlinejudge.service.IProblemCommentsService;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.service.IProblemsService;
import com.oj.onlinejudge.service.IUsersService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/12/23
 */
@Api(tags = "题目评论控制器", description = "处理题目评论的增删改查操作")
@RestController
@RequiredArgsConstructor
@RequestMapping("/comments")
public class ProblemCommentsController {

    private final IProblemCommentsService commentsService;
    private final IUsersService usersService;
    private final IProblemsService problemsService;


    @ApiOperation(value = "发布评论", notes = "用户发布对题目的评论")
    @PostMapping
    @SaCheckLogin
    public ApiResponse<?> addComment(@RequestBody ProblemComments comment) {
        try {
            System.out.println("评论内容：" + comment);

            // 获取当前登录用户 ID
            Object loginId = StpUtil.getLoginId();
            comment.setUserId(Integer.parseInt(loginId.toString()));

            // 设置其他相关信息
            String username = usersService.getUserById(comment.getUserId()).getUsername();
            comment.setUsername(username);
            comment.setProblemTitle(problemsService.getProblemById(comment.getProblemId()).getTitle());

            // 插入评论
            boolean result = commentsService.addComment(comment);

            return new ApiResponse<>(result ? 200 : 500, result ? "成功" : "失败", null);
        } catch (Exception e) {
            return new ApiResponse<>(500, "失败: " + e.getMessage(), null);
        }
    }


    @ApiOperation(value = "删除评论", notes = "用户根据ID删除自己的评论")
    @DeleteMapping("/delete/{id}")
    @SaCheckLogin
    public ApiResponse<?> deleteComment(@PathVariable Integer id) {
        try {
            Users user = usersService.getUserById(StpUtil.getLoginIdAsInt());
            System.out.println();
            System.out.println(commentsService.getById(id).getUserId().equals(StpUtil.getLoginIdAsInt()));
            if (commentsService.getById(id).getUserId().equals(StpUtil.getLoginIdAsInt()) || user.getRole()== Role.TEACHER) {
                boolean result = commentsService.deleteCommentById(id);
                return new ApiResponse<>(result ? 200 : 500, result ? "成功" : "失败", null);
            }
            return new ApiResponse<>(403, "无权限删除", null);


        } catch (Exception e) {
            return new ApiResponse<>(500, "失败: " + e.getMessage(), null);
        }
    }

    @ApiOperation(value = "查询题目所有评论", notes = "根据题目ID查询所有相关评论")
    @GetMapping("/problem/{problemId}")
    public ApiResponse<List<ProblemComments>> getCommentsByProblemId(@PathVariable Integer problemId) {
        try {
            List<ProblemComments> comments = commentsService.getCommentsByProblemId(problemId);
            return new ApiResponse<>(200, "成功", comments);
        } catch (Exception e) {
            return new ApiResponse<>(500, "失败: " + e.getMessage(), null);
        }
    }

    @ApiOperation(value = "分页查询评论", notes = "管理员分页查询所有评论")
    @GetMapping("/page")
    public ApiResponse<Page<ProblemComments>> adminGetCommentsPage(
            @RequestParam(defaultValue = "0") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String query) {
        try {
            Page<ProblemComments> scenicareaPage = new Page<>(current, size);
            Page<ProblemComments> commentsPage = commentsService.adminGetCommentsPage(scenicareaPage, query);
            return new ApiResponse<>(200, "成功", commentsPage);
        } catch (Exception e) {
            return new ApiResponse<>(500, "失败: " + e.getMessage(), null);
        }
    }

    @PostMapping("/deleteBatch")
    @Transactional
    @ApiOperation(value = "批量删除评论", notes = "管理员根据评论ID批量删除评论")
    public ApiResponse<?> deleteCommentsBatch(@RequestBody List<Integer> ids) {
        try {
            if (ids == null || ids.isEmpty()){
                return new ApiResponse<>(400, "ID列表不能为空", null);
            }
            boolean result = commentsService.removeByIds(ids);
            return new ApiResponse<>(result ? 200 : 500, result ? "成功" : "失败", null);
        } catch (Exception e) {
            return new ApiResponse<>(500, "失败: " + e.getMessage(), null);
        }
    }
}