package com.oj.onlinejudge.domain.vo;

import com.oj.onlinejudge.domain.enums.Role;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author : F
 * @项目名称 : OnlineJudge
 * @创建者 : flower
 * @date : 2024/11/27 上午10:00
 */
@Data
@ApiModel(value = "UserLoginVO对象", description = "用户登录响应对象")
public class UserLoginVO {

    @ApiModelProperty(value = "用户ID")
    private Integer id;

    @ApiModelProperty(value = "用户名")
    private String username;

    @ApiModelProperty(value = "角色：学生或教师")
    private Role role;

    @ApiModelProperty(value = "电子邮件地址")
    private String email;

    @ApiModelProperty(value = "学生号，仅当角色为学生时有效")
    private String studentNumber;

    @ApiModelProperty(value = "教师号，仅当角色为教师时有效")
    private String teacherNumber;

    @ApiModelProperty(value = "用户等级，默认值为 1")
    private Integer level;

    @ApiModelProperty(value = "最后登录时间")
    private LocalDateTime lastLogin;

    @ApiModelProperty(value = "用户创建时间")
    private LocalDateTime createdAt;

    @ApiModelProperty(value = "用户更新时间")
    private LocalDateTime updatedAt;

    @ApiModelProperty(value = "satoken")
    private String satoken;
    @ApiModelProperty(value = "用户提交成功数")
    private Float passRate;

    @ApiModelProperty(value = "用户总得分")
    private Integer totalScore;

    @ApiModelProperty(value = "用户AI点数")
    private Integer points;
}
