package com.oj.onlinejudge.controller;

import com.oj.onlinejudge.domain.po.Users;
import com.oj.onlinejudge.domain.response.ApiResponse;
import com.oj.onlinejudge.domain.vo.LeaderboardEntry;
import com.oj.onlinejudge.service.IUsersService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author : 毛晖
 * @项目名称 : OnlineJudge
 * @创建者 : 毛晖
 * @date : 2024/12/25 上午2:55
 */
@Api(tags = "排行榜接口", description = "获取用户排行榜数据")
@RestController
@RequiredArgsConstructor
@RequestMapping("/leaderboard")
public class LeaderboardController {

    private final IUsersService usersService;

    @ApiOperation(value = "获取通过数最多的排行榜", notes = "按通过数降序排列")
    @GetMapping("/top-pass")
    public ApiResponse<?> getTopPassUsers(
            @RequestParam(defaultValue = "10") int limit) {
        List<Users> users = usersService.getTopPassUsers(limit);
        return ApiResponse.success(users);
    }

    @ApiOperation(value = "获取正确率最高的排行榜", notes = "按正确率降序排列")
    @GetMapping("/top-accuracy")
    public ApiResponse<?> getTopAccuracyUsers(
            @RequestParam(defaultValue = "10") int limit) {
        List<Users> users = usersService.getTopAccuracyUsers(limit);
        return ApiResponse.success(users);
    }

    @ApiOperation(value = "获取总得分最高的排行榜", notes = "按总得分降序排列")
    @GetMapping("/top-score")
    public ApiResponse<?> getTopScoreUsers(
            @RequestParam(defaultValue = "10") int limit) {
        List<Users> users = usersService.getTopScoreUsers(limit);
        return ApiResponse.success(users);
    }

    @ApiOperation(value = "获取通过数最多的排行榜（简化版）", notes = "按通过数降序排列，仅返回用户名和通过数")
    @GetMapping("/top-pass-users")
    public ApiResponse<List<LeaderboardEntry>> getTopPassUsersSimple(
            @RequestParam(defaultValue = "10") int limit) {
        List<LeaderboardEntry> result = usersService.getTopPassUsers(limit).stream()
                .map(user -> new LeaderboardEntry(user.getUsername(), user.getSuccessfulSubmissions()))
                .collect(Collectors.toList());

        return ApiResponse.success(result);
    }

    @ApiOperation(value = "获取正确率最高的排行榜（简化版）", notes = "按正确率降序排列，仅返回用户名和正确率")
    @GetMapping("/top-accuracy-users")
    public ApiResponse<List<LeaderboardEntry>> getTopAccuracyUsersSimple(
            @RequestParam(defaultValue = "10") int limit) {
        List<LeaderboardEntry> result = usersService.getTopAccuracyUsers(limit).stream()
                .map(user -> {
                    // 非空判断，计算正确率
                    Integer successfulSubmissions = user.getSuccessfulSubmissions() == null ? 0 : user.getSuccessfulSubmissions();
                    Integer totalSubmissions = user.getTotalSubmissions() == null || user.getTotalSubmissions() == 0 ? 1 : user.getTotalSubmissions(); // 防止除以 0
                    double accuracy = ((double) successfulSubmissions / totalSubmissions) * 100;

                    return new LeaderboardEntry(user.getUsername(), accuracy);
                })
                .collect(Collectors.toList());

        return ApiResponse.success(result);
    }


    @ApiOperation(value = "获取总得分最高的排行榜（简化版）", notes = "按总得分降序排列，仅返回用户名和总得分")
    @GetMapping("/top-score-users")
    public ApiResponse<List<LeaderboardEntry>> getTopScoreUsersSimple(
            @RequestParam(defaultValue = "10") int limit) {
        List<LeaderboardEntry> result = usersService.getTopScoreUsers(limit).stream()
                .map(user -> new LeaderboardEntry(user.getUsername(), user.getTotalScore()))
                .collect(Collectors.toList());

        return ApiResponse.success(result);
    }

}
