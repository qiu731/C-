package com.oj.onlinejudge.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

/**
 * 错误响应类
 *
 * @author flower
 * @项目名称 : OnlineJudge
 */
@Data
public class ErrorResponse {
    private int status;
    private String message;
    private String details;
    private String path;

    public ErrorResponse() {}

    public ErrorResponse(int status, String message, String details, String path) {
        this.status = status;
        this.message = message;
        this.details = details;
        this.path = path;
    }

    public static ErrorResponse of(HttpStatus status, String message, String details, String path) {
        return new ErrorResponse(status.value(), message, details, path);
    }
}