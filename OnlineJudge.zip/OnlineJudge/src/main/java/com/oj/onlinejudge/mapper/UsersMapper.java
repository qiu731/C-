package com.oj.onlinejudge.mapper;

import com.oj.onlinejudge.domain.po.Users;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Update;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author flower
 * @since 2024-11-14
 */
public interface UsersMapper extends BaseMapper<Users> {
    @Update("UPDATE users SET total_submissions = total_submissions + 1 WHERE id = #{userId}")
    void incrementTotalSubmissions(int userId);

    @Update("UPDATE users SET successful_submissions = successful_submissions + 1 WHERE id = #{userId}")
    void incrementSuccessfulSubmissions(int userId);
}
