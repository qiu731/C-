package com.oj.onlinejudge.exception;

/**
 * @author : 毛晖
 * @项目名称 : OnlineJudge
 * @创建者 : 毛晖
 * @date : 2024/12/24 下午10:43
 */
public class UnauthorizedException extends RuntimeException {
    public UnauthorizedException(String message) {
        super(message);
    }
}
